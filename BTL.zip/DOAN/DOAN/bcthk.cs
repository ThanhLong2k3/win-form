﻿using CrystalDecisions.CrystalReports.Engine;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DOAN
{
    public partial class bcthk : Form
    {
        public bcthk()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adt;
        SqlDataReader dr;
        DataTable data;
        string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\THANHLONG;Initial Catalog=DOAN;Integrated Security=True";


        public void mokn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

        }
        public void dongkn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            mokn();
            string A = comboBox1.SelectedItem.ToString();
            string sql = $"Select * from {A}";
            adt = new SqlDataAdapter(sql, con);
            data = new DataTable();
            adt.Fill(data);
            dtgrwbill.DataSource = data;
            dongkn();
        }
     
        private void viewbill_Click(object sender, EventArgs e)
        {
            mokn();
            string a=comboBox1.SelectedItem.ToString();
            if(a=="SanPham")
            {
                string sql = $"Select*from SanPham";
                adt = new SqlDataAdapter(sql, con);
                data = new DataTable();
                adt.Fill(data);
                CrystalReport2 crsp = new CrystalReport2();
                crsp.SetDataSource(data);
                crsp.Refresh();
                BChangnhap hn = new BChangnhap();
                hn.ShowDialog();
            }    
            else if(a=="KhachHang")
            {
                string sql = $"Select*from KhachHang";
                adt = new SqlDataAdapter(sql, con);
                data = new DataTable();
                adt.Fill(data);
                CrXuat crsp = new CrXuat();
                crsp.SetDataSource(data);
                crsp.Refresh();
                HangXuat hn = new HangXuat();
                hn.ShowDialog();
            }
            else if (a == "NhanVien")
            {
                string sql = $"Select*from NhanVien";
                adt = new SqlDataAdapter(sql, con);
                data = new DataTable();
                adt.Fill(data);
                CrNhanVien crsp = new CrNhanVien();
                crsp.SetDataSource(data);
                crsp.Refresh();
                XNV hn = new XNV();
                hn.ShowDialog();
            }
            else if (a == "DaiLy")
            {
                string sql = $"Select*from DaiLy";
                adt = new SqlDataAdapter(sql, con);
                data = new DataTable();
                adt.Fill(data);
                CrDL crsp = new CrDL();
                crsp.SetDataSource(data);
                crsp.Refresh();
                XDL hn = new XDL();
                hn.ShowDialog();
            }
            else
            {
                string sql = $"Select*from NhaCC";
                adt = new SqlDataAdapter(sql, con);
                data = new DataTable();
                adt.Fill(data);
                CrCC crsp = new CrCC();
                crsp.SetDataSource(data);
                crsp.Refresh();
                XCC hn = new XCC();
                hn.ShowDialog();
            }

            dongkn();




        }
    }
}
