﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DOAN
{
    public partial class doimk : Form
    {
        string tk, mk;
        public doimk(string tk, string mk)
        {
            InitializeComponent();
            this.tk = tk;
            this.mk = mk;
        }
        SqlConnection con;
        SqlCommand cmd;

        string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\THANHLONG;Initial Catalog=QLNhanVien;Integrated Security=True";


        public void mokn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

        }
        public void dongkn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }
        void thucthisql(string sql)
        {
            mokn();
            cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            dongkn();
        }


        private void TTND_Enter(object sender, EventArgs e)
        {

        }

        private void update_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("bạn có chắc chắn muốn thoát?", "thông báo", MessageBoxButtons.YesNo);
            if (r == DialogResult.Yes)
                Close();
        }

        private void doimk_Load(object sender, EventArgs e)
        {
            taikhoan.Text = tk;

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void load_Click(object sender, EventArgs e)
        {
            string mkc = mkcu.Text;
            string nl = nhaplai.Text;
            if (mkc == mk)
            {
                string mkm = mkmoi.Text;
                if (nl == mkm)
                {
                    string sql = " Update NhanVien set MatKhau=N'" + mkm + "'";
                    thucthisql(sql);
                    MessageBox.Show("Mật khẩu của bạn đã được đổi", "thong báo", MessageBoxButtons.OK);
                    Close();
                }
                else
                {
                    MessageBox.Show("mật khẩu mới không khớp!", "thong báo", MessageBoxButtons.OK);
                }
            }
            else
            {
                MessageBox.Show("Mật khẩu của bạn Không đúng!", "thông báo", MessageBoxButtons.OK);
            }

        }
    }
}
