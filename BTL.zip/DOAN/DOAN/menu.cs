﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DOAN
{
    public partial class menu : Form
    {
        private string tk, mk;


        public menu(string tk, string mk)
        {
            InitializeComponent();

            this.tk = tk;
            this.mk = mk;
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adt;
        SqlDataReader dr;
        DataTable data;
        string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\THANHLONG;Initial Catalog=DOAN;Integrated Security=True";


        public void mokn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

        }
        public void dongkn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }
        private void quảnLýSảnPhẩmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SanPham SP=new SanPham();
            this.Hide();
            SP.ShowDialog();
            this.Show();
        }

        private void quảnLýNhânViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(quảnLýNhânViênToolStripMenuItem.Text== "Employee administrator")
            {
                NhanVien nv = new NhanVien();
                this.Hide();
                nv.Show();
                nv.nn();
                this.Show();
            }
            else
            {
                NhanVien nv = new NhanVien();
                this.Hide();
                nv.ShowDialog();
                this.Show();
            }
           
        }

        private void quảnLýKháchHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(quảnLýKháchHàngToolStripMenuItem.Text== "customer management")
            {
                KhachHang kh = new KhachHang();
                this.Hide();
                kh.Show();
                kh.nn();
                this.Show();
            }
            else { 
             KhachHang kh = new KhachHang();
            this.Hide();
            kh.ShowDialog();
            this.Show();
            }
           
        }

        private void đạiLýToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DaiLy dl = new DaiLy();
            this.Hide();
            dl.ShowDialog();
            this.Show();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn Đăng Xuất ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
                Dangnhap fm = new Dangnhap();
                fm.Show();
            }
        }

        private void quảnLýNgườiDùngToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            QLTK QL = new QLTK();
            this.Hide();
            QL.ShowDialog();
            this.Show();
        }

        private void đổiMậtKhẩuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doimk d = new doimk(tk,mk);
            this.Hide();
            d.ShowDialog();
            this.Show();
        }

        private void tìmKiếmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(tìmKiếmToolStripMenuItem.Text=="Search")
            {
                Tim T = new Tim();
                this.Hide();
                T.Show();
                T.nn();
                this.Show();
            }
            else
            {
                Tim T = new Tim();
                this.Hide();
                T.ShowDialog();
                this.Show();
            }
           
        }

        private void danhMụcToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DanhMuc dm = new DanhMuc();
            this.Hide();
            dm.ShowDialog();
            this.Show();
        }

        private void báoCáoThốngKêToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bcthk bc = new bcthk();
            this.Hide();
            bc.ShowDialog();
            this.Show();
        }

        private void trợGiupsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Help h = new Help(tk);
            this.Hide();
            h.ShowDialog();
            this.Show();
        }

        private void hệThốngToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

       

        private void menu_Load(object sender, EventArgs e)
        {
            if(tk!="admin")
            {
                quảnLýNgườiDùngToolStripMenuItem1.Visible = false;
                quảnLýNgườiDùngToolStripMenuItem.Visible = false;
                quảnLýNhânViênToolStripMenuItem.Visible = false;
                đạiLýToolStripMenuItem.Visible = false;
                nhàCungCấpToolStripMenuItem.Visible = false;
            }    
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void aminToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void tiếngAnhToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nn1();   
            
        }
        public void nn1()
        {
            hệThốngToolStripMenuItem.Text = "System"; quảnLýSảnPhẩmToolStripMenuItem.Text = "Product Management";
            tìmKiếmToolStripMenuItem.Text = "Search"; đạiLýToolStripMenuItem.Text = "Authorized Dealer";
            danhMụcToolStripMenuItem.Text = "Category"; nhàCungCấpToolStripMenuItem.Text = "Supplier";
            trợGiupsToolStripMenuItem.Text = "Help"; tiếngAnhToolStripMenuItem.Text = "English";
            đổiMậtKhẩuToolStripMenuItem.Text = "change Password";
            đăngXuấtToolStripMenuItem.Text = "Log Out";
            quảnLýNgườiDùngToolStripMenuItem1.Text = "user management"; tiếngViệtToolStripMenuItem.Text = "Vietnamese";
            báoCáoThốngKêToolStripMenuItem.Text = "Report -statistical ";
            label1.Text = "WORKSHOP REPORT"; label2.Text = "WINDOWS FORM APPLICATION PROGRAMMING";
            label3.Text = "TOPIC: BUILDING THE BOARD SHOP MANAGEMENT SYSTEM";
            quảnLýKháchHàngToolStripMenuItem.Text = "customer management"; quảnLýNhânViênToolStripMenuItem.Text = "Employee administrator";
        }

        private void tiếngViệtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            menu mn = new menu(tk, mk);
            this.Close();
            mn.Show();


        }

        private void nhàCungCấpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(nhàCungCấpToolStripMenuItem.Text == "Supplier")
            {
                nhacc cc = new nhacc();
                this.Hide();
                cc.Show();
                cc.nn();
                this.Show();
            }    
            else
            {
                nhacc cc = new nhacc();
                this.Hide();
                cc.ShowDialog();
                this.Show();
            }    
               
            
        }
    }
}
