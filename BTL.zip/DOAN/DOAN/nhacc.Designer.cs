﻿namespace DOAN
{
    partial class nhacc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(nhacc));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.CCdata = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.CCexit = new System.Windows.Forms.Button();
            this.CCdelete = new System.Windows.Forms.Button();
            this.CCupdate = new System.Windows.Forms.Button();
            this.CCadd = new System.Windows.Forms.Button();
            this.CCload = new System.Windows.Forms.Button();
            this.TTCC = new System.Windows.Forms.GroupBox();
            this.CCdc = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.CCdt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.CCht = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.CCma = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CCdata)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.TTCC.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.TTCC);
            this.panel1.Location = new System.Drawing.Point(3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(795, 447);
            this.panel1.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(297, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(163, 26);
            this.label5.TabIndex = 8;
            this.label5.Text = "Nhà Cung Cấp";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.CCdata);
            this.groupBox3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.Blue;
            this.groupBox3.Location = new System.Drawing.Point(177, 142);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(609, 302);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Danh Sách Nhà Cung Cấp";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // CCdata
            // 
            this.CCdata.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.CCdata.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.CCdata.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.CCdata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CCdata.Location = new System.Drawing.Point(6, 19);
            this.CCdata.Name = "CCdata";
            this.CCdata.Size = new System.Drawing.Size(609, 283);
            this.CCdata.TabIndex = 2;
            this.CCdata.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CCdata_CellClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.CCexit);
            this.groupBox2.Controls.Add(this.CCdelete);
            this.groupBox2.Controls.Add(this.CCupdate);
            this.groupBox2.Controls.Add(this.CCadd);
            this.groupBox2.Controls.Add(this.CCload);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Blue;
            this.groupBox2.Location = new System.Drawing.Point(4, 142);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(167, 302);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Chức Năng";
            // 
            // CCexit
            // 
            this.CCexit.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCexit.ForeColor = System.Drawing.Color.Blue;
            this.CCexit.Image = global::DOAN.Properties.Resources.Button_Close_icon;
            this.CCexit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CCexit.Location = new System.Drawing.Point(0, 221);
            this.CCexit.Name = "CCexit";
            this.CCexit.Size = new System.Drawing.Size(167, 35);
            this.CCexit.TabIndex = 4;
            this.CCexit.Text = "&Thoát";
            this.CCexit.UseVisualStyleBackColor = true;
            this.CCexit.Click += new System.EventHandler(this.CCexit_Click);
            // 
            // CCdelete
            // 
            this.CCdelete.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCdelete.ForeColor = System.Drawing.Color.Blue;
            this.CCdelete.Image = global::DOAN.Properties.Resources.trash_icon;
            this.CCdelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CCdelete.Location = new System.Drawing.Point(0, 171);
            this.CCdelete.Name = "CCdelete";
            this.CCdelete.Size = new System.Drawing.Size(167, 35);
            this.CCdelete.TabIndex = 3;
            this.CCdelete.Text = "&Xóa";
            this.CCdelete.UseVisualStyleBackColor = true;
            this.CCdelete.Click += new System.EventHandler(this.CCdelete_Click);
            // 
            // CCupdate
            // 
            this.CCupdate.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCupdate.ForeColor = System.Drawing.Color.Blue;
            this.CCupdate.Image = global::DOAN.Properties.Resources.fix_it_icon;
            this.CCupdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CCupdate.Location = new System.Drawing.Point(0, 120);
            this.CCupdate.Name = "CCupdate";
            this.CCupdate.Size = new System.Drawing.Size(167, 35);
            this.CCupdate.TabIndex = 2;
            this.CCupdate.Text = "&Sửa";
            this.CCupdate.UseVisualStyleBackColor = true;
            this.CCupdate.Click += new System.EventHandler(this.CCupdate_Click);
            // 
            // CCadd
            // 
            this.CCadd.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCadd.ForeColor = System.Drawing.Color.Blue;
            this.CCadd.Image = global::DOAN.Properties.Resources.add_icon;
            this.CCadd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CCadd.Location = new System.Drawing.Point(-1, 70);
            this.CCadd.Name = "CCadd";
            this.CCadd.Size = new System.Drawing.Size(167, 35);
            this.CCadd.TabIndex = 1;
            this.CCadd.Text = "&Thêm";
            this.CCadd.UseVisualStyleBackColor = true;
            this.CCadd.Click += new System.EventHandler(this.CCadd_Click);
            // 
            // CCload
            // 
            this.CCload.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCload.ForeColor = System.Drawing.Color.Blue;
            this.CCload.Image = ((System.Drawing.Image)(resources.GetObject("CCload.Image")));
            this.CCload.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CCload.Location = new System.Drawing.Point(0, 20);
            this.CCload.Name = "CCload";
            this.CCload.Size = new System.Drawing.Size(167, 35);
            this.CCload.TabIndex = 0;
            this.CCload.Text = "&Làm Mới";
            this.CCload.UseVisualStyleBackColor = true;
            this.CCload.Click += new System.EventHandler(this.CCload_Click);
            // 
            // TTCC
            // 
            this.TTCC.Controls.Add(this.CCdc);
            this.TTCC.Controls.Add(this.label4);
            this.TTCC.Controls.Add(this.CCdt);
            this.TTCC.Controls.Add(this.label3);
            this.TTCC.Controls.Add(this.CCht);
            this.TTCC.Controls.Add(this.label2);
            this.TTCC.Controls.Add(this.CCma);
            this.TTCC.Controls.Add(this.label1);
            this.TTCC.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TTCC.ForeColor = System.Drawing.Color.Blue;
            this.TTCC.Location = new System.Drawing.Point(4, 53);
            this.TTCC.Name = "TTCC";
            this.TTCC.Size = new System.Drawing.Size(783, 82);
            this.TTCC.TabIndex = 0;
            this.TTCC.TabStop = false;
            this.TTCC.Text = "Nhà Cung Cấp";
            // 
            // CCdc
            // 
            this.CCdc.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCdc.ForeColor = System.Drawing.Color.Blue;
            this.CCdc.Location = new System.Drawing.Point(659, 31);
            this.CCdc.Name = "CCdc";
            this.CCdc.Size = new System.Drawing.Size(100, 21);
            this.CCdc.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(607, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Địa Chỉ";
            // 
            // CCdt
            // 
            this.CCdt.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCdt.ForeColor = System.Drawing.Color.Blue;
            this.CCdt.Location = new System.Drawing.Point(483, 31);
            this.CCdt.Name = "CCdt";
            this.CCdt.Size = new System.Drawing.Size(100, 21);
            this.CCdt.TabIndex = 5;
            this.CCdt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DLdt_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(431, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Số ĐT";
            // 
            // CCht
            // 
            this.CCht.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCht.ForeColor = System.Drawing.Color.Blue;
            this.CCht.Location = new System.Drawing.Point(287, 31);
            this.CCht.Name = "CCht";
            this.CCht.Size = new System.Drawing.Size(100, 21);
            this.CCht.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(214, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Họ Và Tên";
            // 
            // CCma
            // 
            this.CCma.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCma.ForeColor = System.Drawing.Color.Blue;
            this.CCma.Location = new System.Drawing.Point(85, 31);
            this.CCma.Name = "CCma";
            this.CCma.Size = new System.Drawing.Size(100, 21);
            this.CCma.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(33, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã CC";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // nhacc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "nhacc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "nhacc";
            this.Load += new System.EventHandler(this.nhacc_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CCdata)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.TTCC.ResumeLayout(false);
            this.TTCC.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView CCdata;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button CCexit;
        private System.Windows.Forms.Button CCdelete;
        private System.Windows.Forms.Button CCupdate;
        private System.Windows.Forms.Button CCadd;
        private System.Windows.Forms.Button CCload;
        private System.Windows.Forms.GroupBox TTCC;
        private System.Windows.Forms.TextBox CCdc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox CCdt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox CCht;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox CCma;
        private System.Windows.Forms.Label label1;
    }
}