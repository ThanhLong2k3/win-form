﻿namespace DOAN
{
    partial class doimk
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(doimk));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.TTND = new System.Windows.Forms.GroupBox();
            this.exit = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.nhaplai = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.mkmoi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.mkcu = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.taikhoan = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.TTND.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.TTND);
            this.panel1.Location = new System.Drawing.Point(3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(418, 407);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.ForeColor = System.Drawing.Color.Blue;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(418, 54);
            this.panel2.TabIndex = 10;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(122, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "ĐỔI MẬT KHẨU";
            // 
            // TTND
            // 
            this.TTND.Controls.Add(this.exit);
            this.TTND.Controls.Add(this.update);
            this.TTND.Controls.Add(this.label5);
            this.TTND.Controls.Add(this.nhaplai);
            this.TTND.Controls.Add(this.label4);
            this.TTND.Controls.Add(this.mkmoi);
            this.TTND.Controls.Add(this.label3);
            this.TTND.Controls.Add(this.mkcu);
            this.TTND.Controls.Add(this.label2);
            this.TTND.Controls.Add(this.taikhoan);
            this.TTND.ForeColor = System.Drawing.Color.Blue;
            this.TTND.Location = new System.Drawing.Point(3, 54);
            this.TTND.Name = "TTND";
            this.TTND.Size = new System.Drawing.Size(412, 350);
            this.TTND.TabIndex = 9;
            this.TTND.TabStop = false;
            this.TTND.Text = "Thông Tin Tài Khoản";
            this.TTND.Enter += new System.EventHandler(this.TTND_Enter);
            // 
            // exit
            // 
            this.exit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exit.ForeColor = System.Drawing.Color.Blue;
            this.exit.Image = ((System.Drawing.Image)(resources.GetObject("exit.Image")));
            this.exit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.exit.Location = new System.Drawing.Point(240, 262);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(119, 36);
            this.exit.TabIndex = 18;
            this.exit.Text = "&Thoát";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.update_Click);
            // 
            // update
            // 
            this.update.ForeColor = System.Drawing.Color.Blue;
            this.update.Image = ((System.Drawing.Image)(resources.GetObject("update.Image")));
            this.update.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.update.Location = new System.Drawing.Point(45, 262);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(125, 36);
            this.update.TabIndex = 17;
            this.update.Text = "&Đổi MK";
            this.update.UseVisualStyleBackColor = true;
            this.update.Click += new System.EventHandler(this.load_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(81, 189);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Nhập Lại MK";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // nhaplai
            // 
            this.nhaplai.Location = new System.Drawing.Point(165, 186);
            this.nhaplai.Name = "nhaplai";
            this.nhaplai.Size = new System.Drawing.Size(138, 20);
            this.nhaplai.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(85, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Mật Khẩu Mới";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // mkmoi
            // 
            this.mkmoi.Location = new System.Drawing.Point(165, 131);
            this.mkmoi.Name = "mkmoi";
            this.mkmoi.Size = new System.Drawing.Size(138, 20);
            this.mkmoi.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(85, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Mật Khẩu Cũ";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // mkcu
            // 
            this.mkcu.Location = new System.Drawing.Point(165, 83);
            this.mkcu.Name = "mkcu";
            this.mkcu.Size = new System.Drawing.Size(138, 20);
            this.mkcu.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(85, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Tài Khoản";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // taikhoan
            // 
            this.taikhoan.Enabled = false;
            this.taikhoan.Location = new System.Drawing.Point(165, 37);
            this.taikhoan.Name = "taikhoan";
            this.taikhoan.Size = new System.Drawing.Size(138, 20);
            this.taikhoan.TabIndex = 9;
            // 
            // doimk
            // 
            this.AcceptButton = this.update;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exit;
            this.ClientSize = new System.Drawing.Size(424, 408);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "doimk";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "doimk";
            this.Load += new System.EventHandler(this.doimk_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.TTND.ResumeLayout(false);
            this.TTND.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox TTND;
        private System.Windows.Forms.TextBox nhaplai;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox mkmoi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox mkcu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox taikhoan;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
    }
}