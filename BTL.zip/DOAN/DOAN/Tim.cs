﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DOAN
{
    public partial class Tim : Form
    {
        public Tim()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlDataAdapter adt;
        DataTable data;
        string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\THANHLONG;Initial Catalog=DOAN;Integrated Security=True";
        public void mokn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

        }

        private void Ma_KeyPress(object sender, KeyPressEventArgs e)
        {
           
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            mokn();
            string sql;
            string A = danmuc.SelectedItem.ToString();
            sql = $"Select * from {A}";
            tt(sql);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }
        private void tt(string q)
        {
            adt = new SqlDataAdapter(q, con);
            data = new DataTable();
            adt.Fill(data);
            TKdata.DataSource = data;
            TKdata.Refresh();
            dongkn();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mokn();
            string sql;
            string MA = Ma.Text;
            string t = Ten.Text;
            string A = danmuc.SelectedItem.ToString();
            if (MA == "")
            {
                sql = $"Select * from {A} where Ten=N'" + t + "'";
                tt(sql);

            }
            else if (t  =="")
            {
                sql = $"Select * from {A} where Ma='{MA}'";
                tt(sql);

            }
            
        }
        public void nn()
        {
            label1.Text = "Search";label3.Text = "Category";label2.Text = "ID"; label14.Text = "Name";button1.Text = "Search";button2.Text = "Exit";
            groupBox1.Text = "Attention";label4.Text = "Product";label5.Text = "STAFF";label6.Text = "Client";label7.Text = "Authorized dealer";label8.Text = "Supplier";
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Ma_TextChanged(object sender, EventArgs e)
        {
            string sql;
            string MA = Ma.Text;
            string A = danmuc.SelectedItem.ToString();
            sql = $"Select * from {A} where Ma like'%{MA}%'";
            tt(sql);
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
          
        }

        public void dongkn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }

        private void Ten_TextChanged(object sender, EventArgs e)
        {
            string sql;
            string t = Ten.Text;
            string A = danmuc.SelectedItem.ToString();
            sql = $"Select * from {A} where Ten like N'%{t}%'";
            tt(sql);
        }
    }
}
