﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DOAN
{
    public partial class DanhMuc : Form
    {
        public DanhMuc()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adt;
        SqlDataReader dr;
        DataTable data;
        string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\THANHLONG;Initial Catalog=DOAN;Integrated Security=True";
        public void mokn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

        }
        public void dongkn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }
        void loaddgv_phikn()
        {
            mokn();
            adt = new SqlDataAdapter("Select * from SanPham", con);
            data = new DataTable();
            adt.Fill(data);
            ma.DataSource = data;
            ma.Columns[0].HeaderText = "Mã SP";
            ma.Columns[1].HeaderText = "Tên Đia";
            ma.Columns[2].HeaderText = "Mã Loại";
            ma.Columns[3].HeaderText = "Mô tả";
            ma.Columns[4].HeaderText = "Số lượng";
            ma.Columns[5].HeaderText = "Đơn giá";
            ma.Columns[6].HeaderText = "Tiền Nhập";
        }
        private void kn(string sql)
        {
            adt = new SqlDataAdapter(sql, con);
            data = new DataTable();
            adt.Fill(data);
            ma.DataSource = data;
        }

        private void Action_Click(object sender, EventArgs e)
        {
            string sql = "select * from SanPham where MaLoai=N'Hành Động'";
            kn(sql);
        }

        private void Anime_Click(object sender, EventArgs e)
        {
            string sql = "select * from SanPham where MaLoai=N'Anime'";
            kn(sql);
        }

        private void Cartoon_Click(object sender, EventArgs e)
        {
            string sql = "select * from SanPham where MaLoai=N'Hoạt Hình'";
            kn(sql);
        }

        private void Detective_Click(object sender, EventArgs e)
        {
            string sql = "select * from SanPham where MaLoai=N'Trinh Thám'";
            kn(sql);
        }

        private void Drama_Click(object sender, EventArgs e)
        {
            string sql = "select * from SanPham where MaLoai=N'Hài Kịch'";
            kn(sql);
        }

        private void Horror_Click(object sender, EventArgs e)
        {
            string sql = "select * from SanPham where MaLoai=N'Kinh Dị'";
            kn(sql);
        }

        private void Magic_Click(object sender, EventArgs e)
        {
            string sql = "select * from SanPham where MaLoai=N'Viễn Tưởng'";
            kn(sql);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string sql = "select * from SanPham where MaLoai=N'Tình Cảm'";
            kn(sql);
        }

        private void DanhMuc_Load(object sender, EventArgs e)
        {
            loaddgv_phikn();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
