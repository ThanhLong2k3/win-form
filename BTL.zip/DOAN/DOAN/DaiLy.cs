﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DOAN
{
    public partial class DaiLy : Form
    {
        public DaiLy()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adt;
        SqlDataReader dr;
        DataTable data;
        string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\THANHLONG;Initial Catalog=DOAN;Integrated Security=True";


        public void mokn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

        }
        public void dongkn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }
        void thucthisql(string sql)
        {
            mokn();
            cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            dongkn();
        }


        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

       
        void DLloaddgv_phikn()
        {
            mokn();
            adt = new SqlDataAdapter("Select * from DaiLy", con);
            data = new DataTable();
            adt.Fill(data);
            DLdata.DataSource = data;
            DLdata.Columns[0].HeaderText = "Mã DL";
            DLdata.Columns[1].HeaderText = "Họ Tên";
            DLdata.Columns[2].HeaderText = "SDT";
            DLdata.Columns[3].HeaderText = "Địa Chỉ";



        }
        int DLkiemtramatrung(string NVma)
        {
            int i;
            mokn();
            string sql = "Select count(*) from DaiLy where Ma='" + NVma.Trim() + "'";
            cmd = new SqlCommand(sql, con);
            i = (int)(cmd.ExecuteScalar());
            dongkn();
            return i;
        }
        private void DLlammoi()
        {
            foreach (Control ctrl in TTDL.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }
            TTDL.Enabled = true;
            DLma.Enabled = true;
        }

        private void DLload_Click(object sender, EventArgs e)
        {
            foreach (Control ctrl in TTDL.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }
            DLdt.Text = "";
            TTDL.Enabled = true;
            DLma.Enabled = true;
        }

        private void DLadd_Click(object sender, EventArgs e)
        {
            string maCC = "DL" + DLma.Text;
            string tenCC = DLten.Text;
            string CCdtH = DLdt.Text;
            if (CCdtH.Length < 10)
            {
                MessageBox.Show("Số điện thoại của bạn chưa đúng! hãy nhập lại ", "thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            string CCdcC = DLdc.Text;
            string sql = " Insert into DaiLy values ('" + maCC + "', N'" + tenCC + "', '" + CCdtH + "', N'" + CCdcC + "')";
            if (DLkiemtramatrung(DLma.Text) == 1)
            {
                MessageBox.Show("Mã Nhà CC đã tồn tại, bạn hãy nhập lại mã khác!!!", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            }
            else
            {
                thucthisql(sql);
                DLloaddgv_phikn();
                DLlammoi();

            }
        }

        private void DLupdate_Click(object sender, EventArgs e)
        {
            string maCC = DLma.Text;
            string tenCC = DLten.Text;
            string CCdtH = DLdt.Text;
            if (CCdtH.Length < 10)
            {
                MessageBox.Show("Số điện thoại của bạn chưa đúng! hãy nhập lại ", "thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            string CCdcC = DLdc.Text;
            string sql = " Update DaiLy set Ten= N'" + tenCC + "',SDT= '" + CCdtH + "',DiaChi= N'" + CCdcC + "'where Ma= '" + maCC + "'";
            thucthisql(sql);
            DLloaddgv_phikn();
            DLlammoi();
        }

        private void DLdelete_Click(object sender, EventArgs e)
        {
            string masp = DLma.Text;
            string sql = "Delete from DaiLy where Ma='" + masp + "' ";


            DialogResult dr = MessageBox.Show("Bạn có Chắc chắn muốn xóa Đại Lý", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                thucthisql(sql);
                DLloaddgv_phikn();
                DLlammoi();

            }
        }

        private void DLexit_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }

        private void DLdata_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DaiLy_Load(object sender, EventArgs e)
        {
            DLloaddgv_phikn();
            
        }

        private void DLdata_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) { return; }
            DLma.Text = DLdata[0, i].Value.ToString();
            DLten.Text = DLdata[1, i].Value.ToString();
            DLdt.Text = DLdata[2, i].Value.ToString();
            DLdc.Text = DLdata[3, i].Value.ToString();
            DLma.Enabled = false;
        }
    }
}
