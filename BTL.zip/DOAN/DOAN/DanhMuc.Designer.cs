﻿namespace DOAN
{
    partial class DanhMuc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DanhMuc));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Action = new System.Windows.Forms.Button();
            this.Anime = new System.Windows.Forms.Button();
            this.Cartoon = new System.Windows.Forms.Button();
            this.Detective = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.Magic = new System.Windows.Forms.Button();
            this.Horror = new System.Windows.Forms.Button();
            this.Drama = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ma = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ma)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(165)))), ((int)(((byte)(165)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(6, 8);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(920, 94);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DOAN.Properties.Resources.Button_Close_icon;
            this.pictureBox1.Location = new System.Drawing.Point(883, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(37, 35);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(316, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(263, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Danh Mục Sản Phẩm";
            // 
            // Action
            // 
            this.Action.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(202)))), ((int)(((byte)(202)))));
            this.Action.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Action.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Action.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Action.ForeColor = System.Drawing.Color.Blue;
            this.Action.Image = ((System.Drawing.Image)(resources.GetObject("Action.Image")));
            this.Action.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Action.Location = new System.Drawing.Point(56, 137);
            this.Action.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Action.Name = "Action";
            this.Action.Size = new System.Drawing.Size(158, 68);
            this.Action.TabIndex = 1;
            this.Action.Text = "Hành Động";
            this.Action.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Action.UseVisualStyleBackColor = false;
            this.Action.Click += new System.EventHandler(this.Action_Click);
            // 
            // Anime
            // 
            this.Anime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(202)))), ((int)(((byte)(202)))));
            this.Anime.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Anime.ForeColor = System.Drawing.Color.Blue;
            this.Anime.Image = ((System.Drawing.Image)(resources.GetObject("Anime.Image")));
            this.Anime.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Anime.Location = new System.Drawing.Point(293, 137);
            this.Anime.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Anime.Name = "Anime";
            this.Anime.Size = new System.Drawing.Size(158, 68);
            this.Anime.TabIndex = 2;
            this.Anime.Text = "Anime";
            this.Anime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Anime.UseVisualStyleBackColor = false;
            this.Anime.Click += new System.EventHandler(this.Anime_Click);
            // 
            // Cartoon
            // 
            this.Cartoon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(202)))), ((int)(((byte)(202)))));
            this.Cartoon.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cartoon.ForeColor = System.Drawing.Color.Blue;
            this.Cartoon.Image = ((System.Drawing.Image)(resources.GetObject("Cartoon.Image")));
            this.Cartoon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Cartoon.Location = new System.Drawing.Point(519, 137);
            this.Cartoon.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Cartoon.Name = "Cartoon";
            this.Cartoon.Size = new System.Drawing.Size(158, 68);
            this.Cartoon.TabIndex = 3;
            this.Cartoon.Text = "Hoạt Hình";
            this.Cartoon.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Cartoon.UseVisualStyleBackColor = false;
            this.Cartoon.Click += new System.EventHandler(this.Cartoon_Click);
            // 
            // Detective
            // 
            this.Detective.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(202)))), ((int)(((byte)(202)))));
            this.Detective.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Detective.ForeColor = System.Drawing.Color.Blue;
            this.Detective.Image = ((System.Drawing.Image)(resources.GetObject("Detective.Image")));
            this.Detective.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Detective.Location = new System.Drawing.Point(732, 137);
            this.Detective.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Detective.Name = "Detective";
            this.Detective.Size = new System.Drawing.Size(158, 68);
            this.Detective.TabIndex = 4;
            this.Detective.Text = "Trinh Thám";
            this.Detective.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Detective.UseVisualStyleBackColor = false;
            this.Detective.Click += new System.EventHandler(this.Detective_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(202)))), ((int)(((byte)(202)))));
            this.button5.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Blue;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(732, 232);
            this.button5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(158, 68);
            this.button5.TabIndex = 8;
            this.button5.Text = "Tình Cảm";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // Magic
            // 
            this.Magic.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(202)))), ((int)(((byte)(202)))));
            this.Magic.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Magic.ForeColor = System.Drawing.Color.Blue;
            this.Magic.Image = ((System.Drawing.Image)(resources.GetObject("Magic.Image")));
            this.Magic.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Magic.Location = new System.Drawing.Point(519, 232);
            this.Magic.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Magic.Name = "Magic";
            this.Magic.Size = new System.Drawing.Size(158, 68);
            this.Magic.TabIndex = 7;
            this.Magic.Text = "Viễn Tưởng";
            this.Magic.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Magic.UseVisualStyleBackColor = false;
            this.Magic.Click += new System.EventHandler(this.Magic_Click);
            // 
            // Horror
            // 
            this.Horror.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(202)))), ((int)(((byte)(202)))));
            this.Horror.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Horror.ForeColor = System.Drawing.Color.Blue;
            this.Horror.Image = ((System.Drawing.Image)(resources.GetObject("Horror.Image")));
            this.Horror.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Horror.Location = new System.Drawing.Point(293, 232);
            this.Horror.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Horror.Name = "Horror";
            this.Horror.Size = new System.Drawing.Size(158, 68);
            this.Horror.TabIndex = 6;
            this.Horror.Text = "Kinh Dị";
            this.Horror.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Horror.UseVisualStyleBackColor = false;
            this.Horror.Click += new System.EventHandler(this.Horror_Click);
            // 
            // Drama
            // 
            this.Drama.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(202)))), ((int)(((byte)(202)))));
            this.Drama.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Drama.ForeColor = System.Drawing.Color.Blue;
            this.Drama.Image = ((System.Drawing.Image)(resources.GetObject("Drama.Image")));
            this.Drama.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Drama.Location = new System.Drawing.Point(56, 232);
            this.Drama.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Drama.Name = "Drama";
            this.Drama.Size = new System.Drawing.Size(158, 68);
            this.Drama.TabIndex = 5;
            this.Drama.Text = "Hài Kịch";
            this.Drama.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Drama.UseVisualStyleBackColor = false;
            this.Drama.Click += new System.EventHandler(this.Drama_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(202)))), ((int)(((byte)(202)))));
            this.groupBox1.Controls.Add(this.ma);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Blue;
            this.groupBox1.Location = new System.Drawing.Point(10, 318);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Size = new System.Drawing.Size(909, 187);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Danh Sách Sản Phẩm";
            // 
            // ma
            // 
            this.ma.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ma.BackgroundColor = System.Drawing.SystemColors.Control;
            this.ma.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ma.Location = new System.Drawing.Point(4, 14);
            this.ma.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ma.Name = "ma";
            this.ma.Size = new System.Drawing.Size(901, 173);
            this.ma.TabIndex = 0;
            // 
            // DanhMuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 519);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.Magic);
            this.Controls.Add(this.Horror);
            this.Controls.Add(this.Drama);
            this.Controls.Add(this.Detective);
            this.Controls.Add(this.Cartoon);
            this.Controls.Add(this.Anime);
            this.Controls.Add(this.Action);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "DanhMuc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DanhMuc";
            this.Load += new System.EventHandler(this.DanhMuc_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ma)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Action;
        private System.Windows.Forms.Button Anime;
        private System.Windows.Forms.Button Cartoon;
        private System.Windows.Forms.Button Detective;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button Magic;
        private System.Windows.Forms.Button Horror;
        private System.Windows.Forms.Button Drama;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView ma;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}