﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DOAN
{
    public partial class QLTK : Form
    {
        public QLTK()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adt;
        SqlDataReader dr;
        DataTable data;
        string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\THANHLONG;Initial Catalog=QLNhanVien;Integrated Security=True";

        void thucthisql(string sql)
        {
            mokn();
            cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            dongkn();
        }
        public void mokn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

        }
        public void dongkn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }
        void loaddgv_phikn()
        {
            mokn();
            adt = new SqlDataAdapter("Select * from NhanVien", con);
            data = new DataTable();
            adt.Fill(data);
            NDdata.DataSource = data;
            NDdata.Columns[0].HeaderText = "Ma";
            NDdata.Columns[1].HeaderText = "Tài Khoản";
            NDdata.Columns[2].HeaderText = "Mật Khẩu";
            NDdata.Columns[3].HeaderText = "Quyền truy cập";

        }

        private void NDdata_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) return;
            ma.Text = NDdata[0, i].Value.ToString();
            TK.Text = NDdata[1, i].Value.ToString();
            MK.Text = NDdata[2, i].Value.ToString();
            Q.Text = NDdata[3, i].Value.ToString();
        }
        private void lammoi()
        {
            foreach (Control ctrl in TTND.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }
            TTND.Enabled = true;
        }
        private void load_Click(object sender, EventArgs e)
        {
            foreach (Control ctrl in TTND.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }
            TTND.Enabled = true;
        }

        private void update_Click(object sender, EventArgs e)
        {

            int m = int.Parse(ma.Text);
            string tk = TK.Text;
            string mk = MK.Text;
            int q = int.Parse(Q.Text);
            if (q == 1)
            {
                DialogResult r = MessageBox.Show("Bạn có muốn cấp quyền ADMIN cho tài khoản này ?", "thông báo!", MessageBoxButtons.YesNo);
                if (r == DialogResult.Yes)
                {
                    string sql = "Update NhanVien set TaiKhoan = '" + tk + "',MatKhau='" + mk + "',IDPer='" + q + "'where MaNV='" + m + "'";
                    thucthisql(sql);
                    loaddgv_phikn();
                }
                else
                {
                    Q.Focus();
                }

            }
            else
            {
                if (q == 0)
                {
                    DialogResult r = MessageBox.Show("Bạn có muốn cấp quyền User cho tài khoản này ?", "thông báo!", MessageBoxButtons.YesNo);
                    if (r == DialogResult.Yes)
                    {
                        string sql = "Update NhanVien set TaiKhoan = '" + tk + "',MatKhau='" + mk + "',IDPer='" + q + "'where MaNV='" + m + "'";
                        thucthisql(sql);
                        loaddgv_phikn();
                    }
                    else
                    {
                        Q.Focus();
                    }
                }

                else
                {
                    MessageBox.Show("bạn phải nhập quền là (0):user ; (1): admin", "thông báo", MessageBoxButtons.OK);
                }
            }

            Q.Focus();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            string maspp = ma.Text;
            string sql = "Delete from NhanVien where MaNV='" + maspp + "' ";


            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muốn xóa Tài Khoản này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                thucthisql(sql);
                loaddgv_phikn();
            }
            lammoi();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("bạn có chắc chắn muốn thoát?", "thông báo", MessageBoxButtons.YesNo);
            if (r == DialogResult.Yes)
                Close();
        }

        private void QLTK_Load(object sender, EventArgs e)
        {
            loaddgv_phikn();
        }
    }

}


