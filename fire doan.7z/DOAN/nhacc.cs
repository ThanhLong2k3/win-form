﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DOAN
{
    public partial class nhacc : Form
    {
        public nhacc()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adt;
        SqlDataReader dr;
        DataTable data;
        string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\THANHLONG;Initial Catalog=DOAN;Integrated Security=True";


        public void mokn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

        }
        public void dongkn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }
        void thucthisql(string sql)
        {
            mokn();
            cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            dongkn();
        }


        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void DLdt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }
        private void CClammoi()
        {
            foreach (Control ctrl in TTCC.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }
            CCdt.Text = "";
            TTCC.Enabled = true;
        }
        int CCkiemtramatrung(string NVma)
        {
            int i;
            mokn();
            string sql = "Select count(*) from NhaCC where Ma='" + NVma.Trim() + "'";
            cmd = new SqlCommand(sql, con);
            i = (int)(cmd.ExecuteScalar());
            dongkn();
            return i;
        }
        void CCloaddgv_phikn()
        {
            mokn();
            adt = new SqlDataAdapter("Select * from NhaCC", con);
            data = new DataTable();
            adt.Fill(data);
            CCdata.DataSource = data;
            CCdata.Columns[0].HeaderText = "Mã CC";
            CCdata.Columns[1].HeaderText = "Họ Tên";
            CCdata.Columns[2].HeaderText = "SDT";
            CCdata.Columns[3].HeaderText = "Địa Chỉ";



        }

        private void CCload_Click(object sender, EventArgs e)
        {

            foreach (Control ctrl in TTCC.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }
            CCdt.Text = "";
            TTCC.Enabled = true;
            CCma.Enabled = true;
        }

        private void CCadd_Click(object sender, EventArgs e)
        {

            string maCC = "CC" + CCma.Text;
            string tenCC = CCht.Text;
            string CCdtH = CCdt.Text;
            if (CCdtH.Length < 10)
            {
                MessageBox.Show("Số điện thoại của bạn chưa đúng! hãy nhập lại ", "thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            string CCdcC = CCdc.Text;
            string sql = " Insert into NhaCC values ('" + maCC + "', N'" + tenCC + "', '" + CCdtH + "', N'" + CCdcC + "')";
            if (CCkiemtramatrung(CCma.Text) == 1)
            {
                MessageBox.Show("Mã Nhà CC đã tồn tại, bạn hãy nhập lại mã khác!!!", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            }
            else
            {
                thucthisql(sql);
                CCloaddgv_phikn();
                CClammoi();

            }
        }

        private void CCupdate_Click(object sender, EventArgs e)
        {
            string maCC = CCma.Text;
            string tenCC = CCht.Text;
            string CCdtH = CCdt.Text;
            if (CCdtH.Length < 10)
            {
                MessageBox.Show("Số điện thoại của bạn chưa đúng! hãy nhập lại ", "thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            string CCdcC = CCdc.Text;
            string sql = " Update NhaCC set Ten= N'" + tenCC + "',SDT= '" + CCdtH + "',DiaChi= N'" + CCdcC + "'where Ma= '" + maCC + "'";
            thucthisql(sql);
            CCloaddgv_phikn();
            CClammoi();
        }

        private void CCdelete_Click(object sender, EventArgs e)
        {
            string masp = CCma.Text;
            string sql = "Delete from NhaCC where Ma='" + masp + "' ";


            DialogResult dr = MessageBox.Show("Bạn có Chắc chắn muốn xóa nhà cc", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                thucthisql(sql);
                CCloaddgv_phikn();
                CClammoi();
            }
        }

        private void CCexit_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }

        private void nhacc_Load(object sender, EventArgs e)
        {
            CCloaddgv_phikn();
           
        }
        public void nn()
        {
            label5.Text = "Supplier"; TTCC.Text = "Supplier"; label1.Text = "ID"; label2.Text = "First and last name";label3.Text = "Phone Number";label4.Text = "Address";
            groupBox2.Text = "Function";groupBox3.Text = "Supplier List";CCload.Text = "Refresh";CCadd.Text = "More";CCupdate.Text = "fix";CCdelete.Text = "Delete";CCexit.Text = "Exit";
        }

        private void CCdata_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) return;
            CCma.Text = CCdata[0, i].Value.ToString();
            CCht.Text = CCdata[1, i].Value.ToString();
            CCdt.Text = CCdata[2, i].Value.ToString();
            CCdc.Text = CCdata[3, i].Value.ToString();
            CCma.Enabled = false;
        }
    }
}
