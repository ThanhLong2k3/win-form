﻿namespace DOAN
{
    partial class QLTK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.exit = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.load = new System.Windows.Forms.Button();
            this.TTND = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Q = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.MK = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TK = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ma = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.NDdata = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.TTND.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NDdata)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.exit);
            this.panel1.Controls.Add(this.delete);
            this.panel1.Controls.Add(this.update);
            this.panel1.Controls.Add(this.load);
            this.panel1.Controls.Add(this.TTND);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(418, 407);
            this.panel1.TabIndex = 0;
            // 
            // exit
            // 
            this.exit.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit.ForeColor = System.Drawing.Color.Blue;
            this.exit.Image = global::DOAN.Properties.Resources.Button_Close_icon;
            this.exit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.exit.Location = new System.Drawing.Point(223, 337);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(119, 35);
            this.exit.TabIndex = 13;
            this.exit.Text = "&Thoát";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // delete
            // 
            this.delete.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delete.ForeColor = System.Drawing.Color.Blue;
            this.delete.Image = global::DOAN.Properties.Resources.trash_icon;
            this.delete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.delete.Location = new System.Drawing.Point(49, 337);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(123, 35);
            this.delete.TabIndex = 12;
            this.delete.Text = "&Xóa";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // update
            // 
            this.update.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update.ForeColor = System.Drawing.Color.Blue;
            this.update.Image = global::DOAN.Properties.Resources.fix_it_icon;
            this.update.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.update.Location = new System.Drawing.Point(223, 277);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(119, 36);
            this.update.TabIndex = 11;
            this.update.Text = "&Sửa";
            this.update.UseVisualStyleBackColor = true;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // load
            // 
            this.load.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.load.ForeColor = System.Drawing.Color.Blue;
            this.load.Image = global::DOAN.Properties.Resources.sync_icon;
            this.load.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.load.Location = new System.Drawing.Point(49, 277);
            this.load.Name = "load";
            this.load.Size = new System.Drawing.Size(125, 36);
            this.load.TabIndex = 10;
            this.load.Text = "&Làm Mới";
            this.load.UseVisualStyleBackColor = true;
            this.load.Click += new System.EventHandler(this.load_Click);
            // 
            // TTND
            // 
            this.TTND.Controls.Add(this.label5);
            this.TTND.Controls.Add(this.Q);
            this.TTND.Controls.Add(this.label4);
            this.TTND.Controls.Add(this.MK);
            this.TTND.Controls.Add(this.label3);
            this.TTND.Controls.Add(this.TK);
            this.TTND.Controls.Add(this.label2);
            this.TTND.Controls.Add(this.ma);
            this.TTND.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TTND.ForeColor = System.Drawing.Color.Blue;
            this.TTND.Location = new System.Drawing.Point(3, 44);
            this.TTND.Name = "TTND";
            this.TTND.Size = new System.Drawing.Size(412, 204);
            this.TTND.TabIndex = 9;
            this.TTND.TabStop = false;
            this.TTND.Text = "Thông Tin Tài Khoản";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(105, 170);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 15);
            this.label5.TabIndex = 16;
            this.label5.Text = "Quyền ";
            // 
            // Q
            // 
            this.Q.Location = new System.Drawing.Point(185, 167);
            this.Q.Name = "Q";
            this.Q.Size = new System.Drawing.Size(138, 22);
            this.Q.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(105, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 15);
            this.label4.TabIndex = 14;
            this.label4.Text = "Mật Khẩu";
            // 
            // MK
            // 
            this.MK.Location = new System.Drawing.Point(185, 120);
            this.MK.Name = "MK";
            this.MK.Size = new System.Drawing.Size(138, 22);
            this.MK.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(105, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 15);
            this.label3.TabIndex = 12;
            this.label3.Text = "Tài Khoản";
            // 
            // TK
            // 
            this.TK.Location = new System.Drawing.Point(185, 72);
            this.TK.Name = "TK";
            this.TK.Size = new System.Drawing.Size(138, 22);
            this.TK.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(105, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 15);
            this.label2.TabIndex = 10;
            this.label2.Text = "Mã TK";
            // 
            // ma
            // 
            this.ma.Enabled = false;
            this.ma.Location = new System.Drawing.Point(185, 28);
            this.ma.Name = "ma";
            this.ma.Size = new System.Drawing.Size(138, 22);
            this.ma.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(86, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(250, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Quản Lý Tài Khoản";
            // 
            // NDdata
            // 
            this.NDdata.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.NDdata.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.NDdata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.NDdata.Location = new System.Drawing.Point(423, 2);
            this.NDdata.Name = "NDdata";
            this.NDdata.Size = new System.Drawing.Size(375, 407);
            this.NDdata.TabIndex = 1;
            this.NDdata.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.NDdata_CellClick);
            // 
            // QLTK
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 408);
            this.Controls.Add(this.NDdata);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "QLTK";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QLTK";
            this.Load += new System.EventHandler(this.QLTK_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.TTND.ResumeLayout(false);
            this.TTND.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NDdata)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Button load;
        private System.Windows.Forms.GroupBox TTND;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Q;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox MK;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TK;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ma;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView NDdata;
    }
}