﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DOAN
{
    public partial class SanPham : Form
    {
        public SanPham()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adt;
        SqlDataReader dr;
        DataTable data;
        string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\THANHLONG;Initial Catalog=DOAN;Integrated Security=True";


        public void mokn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

        }
        public void dongkn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }
        private void TTSP_Enter(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void NVgioitinh_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }
        void theloai_Load()//kiến trúc kết nối: connect, command, datareader
        {

            mokn();
            cmd = new SqlCommand("Select * from TheLoai", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                theloai.Items.Add(dr[0].ToString());

            }
            dongkn();
        }

        void thucthisql(string sql)
        {
            mokn();
            cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            dongkn();
        }
        int kiemtramatrung(string ma)
        {
            int i;
            mokn();
            string sql = "Select count(*) from SanPham where Ma='" + ma.Trim() + "'";
            cmd = new SqlCommand(sql, con);
            i = (int)(cmd.ExecuteScalar());
            dongkn();
            return i;
        }

        void loaddgv_phikn()
        {
            mokn();
            adt = new SqlDataAdapter("Select * from SanPham  ORDER BY MA ASC;", con);
            data = new DataTable();
            adt.Fill(data);
            SPdata.DataSource = data;
            SPdata.Columns[0].HeaderText = "Mã SP";
            SPdata.Columns[1].HeaderText = "Tên Đia";
            SPdata.Columns[2].HeaderText = "Mã Loại";
            SPdata.Columns[3].HeaderText = "Mô tả";
            SPdata.Columns[4].HeaderText = "Số lượng";
            SPdata.Columns[5].HeaderText = "Đơn giá";
            SPdata.Columns[6].HeaderText = "Tiền Nhập";
        }


        private void gianhap()
        {
            string sql = "Update SanPham set TienNhap = SoLuong* DonGia from SanPham";
            thucthisql(sql);
        }


        private void dongia_TextChanged(object sender, EventArgs e)
        {

        }

        private void SPdata_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) return;
            masp.Text = SPdata[0, i].Value.ToString();
            tendia.Text = SPdata[1, i].Value.ToString();
            theloai.Text = SPdata[2, i].Value.ToString();
            mota.Text = SPdata[3, i].Value.ToString();
            soluong.Text = SPdata[4, i].Value.ToString();
            dongia.Text = SPdata[5, i].Value.ToString();
            masp.Enabled = false;
        }
        private void SPlammoi()
        {
            foreach (Control ctrl in TTSP.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }
            TTSP.Enabled = true;
            masp.Enabled = true;
        }

        private void SPload_Click(object sender, EventArgs e)
        {
            foreach (Control ctrl in TTSP.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }
            TTSP.Enabled = true;
            masp.Enabled = true;
        }

        private void SPadd_Click(object sender, EventArgs e)
        {
            string maasp = "SP" + masp.Text;
            string tennsp = tendia.Text;
            string theloaia = theloai.Text;
            string moota = mota.Text;
            int ssl = int.Parse(soluong.Text);
            int ddg = int.Parse(dongia.Text);
            int x = int.Parse(soluong.Text) * int.Parse(dongia.Text);

            string sql = " Insert into SanPham values ('" + maasp + "', N'" + tennsp + "', N'" + theloaia + "', N'" + moota + "', '" + ssl + "', '" + ddg + "','" + x + "')";
            if (kiemtramatrung(masp.Text) == 1)
            {
                MessageBox.Show("Mã sp đã tồn tại, bạn hãy nhập lại mã khác!!!", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            }
            else
            {
                thucthisql(sql);

                loaddgv_phikn();

            }
            SPlammoi();
        }

        private void SPupdate_Click(object sender, EventArgs e)
        {
            string maasp = masp.Text;
            string tensp = tendia.Text;
            string theloaii = theloai.Text;
            string moota = mota.Text;
            int sl = int.Parse(soluong.Text);
            int dg = int.Parse(dongia.Text);

            string sql = "Update SanPham set Ten = N'" + tensp + "',MaLoai= N'" + theloaii + "',MoTa=N'" + moota + "',SoLuong = '" + sl + "',DonGia='" + dg + "' where Ma= '" + maasp + "'";
            thucthisql(sql);
            gianhap();
            loaddgv_phikn();
            SPlammoi();
        }

        private void SPdelete_Click(object sender, EventArgs e)
        {
            string maspp = masp.Text;
            string sql = "Delete from SanPham where Ma='" + maspp + "' ";


            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa sản phẩm này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                thucthisql(sql);
                loaddgv_phikn();
            }
            SPlammoi();
        }

        private void SPexit_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }

        private void SanPham_Load(object sender, EventArgs e)
        {
            theloai_Load();
            loaddgv_phikn();
        }
    }
}
