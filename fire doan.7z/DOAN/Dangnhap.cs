﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DOAN
{
    public partial class Dangnhap : Form
    {
        public Dangnhap()
        {
            InitializeComponent();
        }
        string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\THANHLONG;Initial Catalog=QLNhanVien;Integrated Security=True";

        SqlConnection con;
        SqlCommand cmd;
        public void mokn(string c)
        {
            con = new SqlConnection(c);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

        }
        public void dongkn(string c)
        {
            con = new SqlConnection(c);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }
        public static string UserName = "";

        public string a = "admin";
        public string b = "user";
        private void button2_Click(object sender, EventArgs e)
        {
            this.Show(); newtk TK = new newtk();
            this.Hide();
            TK.ShowDialog();
            this.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                mokn(chuoikn);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SP_AuthoLogin";
                cmd.Parameters.AddWithValue("@UserName", taikhoan.Text);
                cmd.Parameters.AddWithValue("@Password", matkhau.Text);
                cmd.Connection = con;
                UserName = taikhoan.Text;
                object kq = cmd.ExecuteScalar();
                int code = Convert.ToInt32(kq);


                if (code == 0)
                {
                    MessageBox.Show("Chào mừng User đăng nhập", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    menu f = new menu(b, matkhau.Text);
                    this.Hide();
                    f.ShowDialog();
                    this.Show();




                }
                else if (code == 1)
                {
                    MessageBox.Show("Chào mừng Admin đăng nhập", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    menu f = new menu(a, matkhau.Text);
                    this.Hide();
                    f.ShowDialog();



                }
                else if (code == 2)
                {
                    MessageBox.Show("Tài khoản hoặc mật khẩu không đúng !!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    matkhau.Text = "";
                    taikhoan.Text = "";
                    taikhoan.Focus();
                }
                else
                {
                    MessageBox.Show("Tài khoản không tồn tại !!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    matkhau.Text = "";
                    taikhoan.Text = "";
                    taikhoan.Focus();
                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            dongkn(chuoikn);
        }

        private void Dangnhap_Load(object sender, EventArgs e)
        {

        }

        private void taikhoan_MouseClick(object sender, MouseEventArgs e)
        {
            taikhoan.SelectAll();
        }

        private void matkhau_MouseClick(object sender, MouseEventArgs e)
        {
            matkhau.SelectAll();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            matkhau.UseSystemPasswordChar = !matkhau.UseSystemPasswordChar;

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
