﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DOAN
{
    public partial class newtk : Form
    {
        public newtk()
        {
            InitializeComponent();
        }
        string tk, mk;
        public newtk(string tk, string mk)
        {
            this.tk = tk;
            this.mk = mk;
        }
        string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\THANHLONG;Initial Catalog=QLNhanVien;Integrated Security=True";

        SqlConnection con;
        SqlCommand cmd;
       
        void thucthisql(string sql)
        {
            mokn();
            cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            dongkn();
        }
        public void mokn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

        }
        public void dongkn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }
        int KHkiemtramatrung(string tkhoan)
        {
            int i;
            mokn();
            string sql = "Select count(*) from NhanVien where TaiKhoan='" + tkhoan+ "'";
            cmd = new SqlCommand(sql, con);
            i = (int)(cmd.ExecuteScalar());
            dongkn();
            return i;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("Bạn có muốn thoát ?", "thông báo", MessageBoxButtons.YesNo);
            if (r == DialogResult.Yes)
                Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String tk = TKhoan.Text;
            string mk = MK.Text;
            string nll = NL.Text;
           
                if (mk == nll)
                {
                    string sql = " Insert into NhanVien values('" + tk + "', '" + mk + "', ' 0 ')";
                    if (KHkiemtramatrung(TKhoan.Text) == 1)
                         {
                    MessageBox.Show("Tên tài khoản đã tồn tại , hãy nhập tên tk khác!!!", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                       }
                    else
                     {
                     thucthisql(sql);
                    DialogResult r = MessageBox.Show("Đã Tạo Tài Khoản thành công ! bặn có muốn quan lại trang đăng nhập ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                     if(r == DialogResult.Yes)
                     {
                        Dangnhap dn = new Dangnhap();
                        this.Close();
                        dn.ShowDialog();

                    }    
                    }
                }
                else
                    MessageBox.Show("Mật khẩu nhập lại chưa khớp!", "thong báo", MessageBoxButtons.OK);
            
        }
    }

       
    
}
