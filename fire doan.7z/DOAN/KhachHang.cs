﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DOAN
{
    public partial class KhachHang : Form
    {
        public KhachHang()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adt;
        SqlDataReader dr;
        DataTable data;
        string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\THANHLONG;Initial Catalog=DOAN;Integrated Security=True";


        public void mokn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

        }
        public void dongkn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }
        void thucthisql(string sql)
        {
            mokn();
            cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            dongkn();
        }
        int KHkiemtramatrung(string NVma)
        {
            int i;
            mokn();
            string sql = "Select count(*) from KhachHang where Ma='" + NVma.Trim() + "'";
            cmd = new SqlCommand(sql, con);
            i = (int)(cmd.ExecuteScalar());
            dongkn();
            return i;
        }
        void KHloaddgv_phikn()
        {
            mokn();
            adt = new SqlDataAdapter("Select * from KhachHang", con);
            data = new DataTable();
            adt.Fill(data);
            KHdata.DataSource = data;
            KHdata.Columns[0].HeaderText = "Mã KH";
            KHdata.Columns[1].HeaderText = "Họ Tên";
            KHdata.Columns[2].HeaderText = "Giới Tính";
            KHdata.Columns[3].HeaderText = "SDT";
            KHdata.Columns[4].HeaderText = "Thể Loại";
            KHdata.Columns[5].HeaderText = "Tên Đĩa";
            KHdata.Columns[6].HeaderText = "Số Lượng";
            KHdata.Columns[7].HeaderText = "Thời Gian";
            KHdata.Columns[8].HeaderText = "Đơn Gía";
            KHdata.Columns[9].HeaderText = "Thành Tiền";




        }
        private void TTNV_Enter(object sender, EventArgs e)
        {

        }

        private void nvdelete_Click(object sender, EventArgs e)
        {
            string masKH = KHma.Text;
            string sql = "Delete from KhachHang where Ma='" + masKH + "' ";


            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa Khách Hàng này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                thucthisql(sql);
                hoan();
                KHloaddgv_phikn();
                KHlammoi();

            }
        }
        private void KHlammoi()
        {
            foreach (Control ctrl in TTKH.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }
            KHsdt.Text = "";
            TTKH.Enabled = true;
            KHma.Enabled = true;
        }

        private void KHload_Click(object sender, EventArgs e)
        {
            foreach (Control ctrl in TTKH.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }
            KHsdt.Text = "";
            KHdate.Text = DateTime.Now.ToString();
            TTKH.Enabled = true;
            KHma.Enabled = true;
        }
        private void hangcon()
        {
            string b = KHtendia.Text;
            int a = int.Parse(CC.Text) - int.Parse(KHsoluog.Text);
            string sql = " Update SanPham set SoLuong = '" + a + "' where Ten= N'" + b + "'";
            thucthisql(sql);

        }
        public void nn()
        {
            label5.Text = "Customer management";TTKH.Text = "Customer information";label1.Text = "ID";label7.Text = "Full Name"; label6.Text = "Date Time";label11.Text = "Category";label8.Text = "Disc Name";label10.Text = "Amount";
            label12.Text = "Single Price";label4.Text = "In stock";label9.Text = "total money";groupBox2.Text = "Function";groupBox3.Text = "List of customers"; label3.Text = "Sex"; label2.Text = "Phone Number";KHload.Text = "Refesh";KHadd.Text = "ADD";KHupdate.Text = "Fix";KHdelete.Text = "Delete";KHexit.Text = "Exit";
        }
        private void hoan()
        {
            string b = KHtendia.Text;
            int a = int.Parse(CC.Text) + int.Parse(KHsoluog.Text);
            string sql = " Update SanPham set SoLuong = '" + a + "' where Ten= N'" + b + "'";
            
            thucthisql(sql);
        }

        private void KHadd_Click(object sender, EventArgs e)
        {
            int x1 = int.Parse(KHsoluog.Text) * int.Parse(KHDongia.Text);
            string maaKH = "KH" + KHma.Text;
            string tennKH = KHhoten.Text;
            string GTKH = KHgt.Text;
            string sdt = KHsdt.Text;
            if (sdt.Length < 10)
            {
                MessageBox.Show("Số điện thoại của bạn chưa đúng! hãy nhập lại ", "thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            string tlKH = KHtheloai.Text;
            string tendia = KHtendia.Text;
          
            int sl = int.Parse(KHsoluog.Text);
            KHdate.Text=DateTime.Now.ToString();
            
            int ddg = int.Parse(KHDongia.Text);
            string sql = " Insert into KhachHang values ('" + maaKH + "', N'" + tennKH + "', N'" + GTKH + "', N'" + sdt + "', N'" + tlKH + "', N'" + tendia + "', '" + sl + "', '" +KHdate.Text + "', '" + ddg + "','" + x1 + "')";
            if (KHkiemtramatrung(KHma.Text) == 1)
            {
                MessageBox.Show("Mã KH đã tồn tại, bạn hãy nhập lại mã khác!!!", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            }
            else
            {
                thucthisql(sql);
                hangcon();
                KHloaddgv_phikn();
                KHlammoi();

            }
        }

        private void KHupdate_Click(object sender, EventArgs e)
        {
            int x1 = int.Parse(KHsoluog.Text) * int.Parse(KHDongia.Text);
            string maaKH = KHma.Text;
            string tennKH = KHhoten.Text;
            string GTKH = KHgt.Text;
            string sdt = KHsdt.Text;
            if (sdt.Length < 10)
            {
                MessageBox.Show("Số điện thoại của bạn chưa đúng! hãy nhập lại ", "thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            string tlKH = KHtheloai.Text;
            string tendia = KHtendia.Text;

            int sl = int.Parse(KHsoluog.Text);
            string DATE = KHdate.Text;

            int ddg = int.Parse(KHDongia.Text);
            string sql = " Update KhachHang set Ten =  N'" + tennKH + "',GioiTinh = N'" + GTKH + "',SDT = '" + sdt + "',TheLoai = N'" + tlKH + "',TenDia = N'" + tendia + "',SoLuong = '" + sl + "',ThoiGian = '" + DATE + "',DonGia = '" + ddg + "',ThanhTien='" + x1 + "' where Ma= '" + maaKH + "'";
            thucthisql(sql);

            KHloaddgv_phikn();
            KHlammoi();
        }

        private void KHdata_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) { return; }
            KHma.Text = KHdata[0, i].Value.ToString();
            KHhoten.Text = KHdata[1, i].Value.ToString();
            KHgt.Text = KHdata[2, i].Value.ToString();
            KHsdt.Text = KHdata[3, i].Value.ToString();
            KHtheloai.Text = KHdata[4, i].Value.ToString();
            KHtendia.Text = KHdata[5, i].Value.ToString();
            KHsoluog.Text = KHdata[6, i].Value.ToString();
            KHdate.Text = KHdata[7, i].Value.ToString();
            KHDongia.Text = KHdata[8, i].Value.ToString();
            tien.Text = KHdata[9, i].Value.ToString();
            KHma.Enabled = false;
        }
        void theloai_Load()
        {

            mokn();
            cmd = new SqlCommand("Select * from TheLoai", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                KHtheloai.Items.Add(dr[0].ToString());
            }
            dongkn();
        }

        void gioitinh_Load()
        {

            mokn();
            cmd = new SqlCommand("Select * from GioiTinh", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                KHgt.Items.Add(dr[0].ToString());
            }
            dongkn();
        }

       

        private void KHsoluog_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void KHexit_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }

        private void KHtheloai_SelectedIndexChanged(object sender, EventArgs e)
        {
            string a = KHtheloai.SelectedItem.ToString();
            string sql = "select Ten from SanPham where  MaLoai=N'" + a + "' ";
            adt = new SqlDataAdapter(sql, con);
            data = new DataTable();
            adt.Fill(data);
            KHtendia.DataSource = data;
            KHtendia.DisplayMember = "Ten";
            KHtendia.ValueMember = "Ten";
        }

        private void KHtendia_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            

            string sql1 = "select SoLuong,DonGia from SanPham where Ten=N'" + KHtendia.Text + "'";
            adt = new SqlDataAdapter(sql1, con);
            data = new DataTable();
            adt.Fill(data);
            CC.DataSource = data;
            CC.DisplayMember = "SoLuong";
            KHDongia.DataSource = data;
            KHDongia.DisplayMember = "DonGia";
        }

        private void KHsoluog_KeyUp(object sender, KeyEventArgs e)
        {
            if (KHsoluog.Text != "")
            {
                if (int.Parse(KHsoluog.Text) <= int.Parse(CC.Text))
                {
                    int x = int.Parse(KHsoluog.Text) * int.Parse(KHDongia.Text);
                    tien.Text = x.ToString();
                }
                else
                {
                    MessageBox.Show("Hàng trong kho không đủ!", "thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else
            {
                tien.Text = "0";
            }
        }

        private void KhachHang_Load(object sender, EventArgs e)
        {
            theloai_Load();
            gioitinh_Load();
            KHloaddgv_phikn();
            KHdate.Text = DateTime.Now.ToString();

        }

        private void KHdata_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void KHsdt_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
           

        }
    }
}
