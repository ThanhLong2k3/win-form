﻿namespace DOAN
{
    partial class KhachHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KhachHang));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.KHdata = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.KHexit = new System.Windows.Forms.Button();
            this.KHdelete = new System.Windows.Forms.Button();
            this.KHupdate = new System.Windows.Forms.Button();
            this.KHadd = new System.Windows.Forms.Button();
            this.KHload = new System.Windows.Forms.Button();
            this.TTKH = new System.Windows.Forms.GroupBox();
            this.KHsdt = new System.Windows.Forms.MaskedTextBox();
            this.KHdate = new System.Windows.Forms.DateTimePicker();
            this.KHDongia = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.KHtheloai = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.KHsoluog = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.KHhoten = new System.Windows.Forms.TextBox();
            this.tien = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.KHtendia = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.KHgt = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.CC = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.KHma = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KHdata)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.TTKH.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.TTKH);
            this.panel1.Location = new System.Drawing.Point(3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(889, 449);
            this.panel1.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(259, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(290, 31);
            this.label5.TabIndex = 8;
            this.label5.Text = "Quản Lý Khách Hàng";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.KHdata);
            this.groupBox3.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.Blue;
            this.groupBox3.Location = new System.Drawing.Point(178, 161);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(697, 302);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Danh Sách Khách Hàng";
            // 
            // KHdata
            // 
            this.KHdata.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.KHdata.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.KHdata.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.KHdata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.KHdata.Location = new System.Drawing.Point(6, 19);
            this.KHdata.Name = "KHdata";
            this.KHdata.Size = new System.Drawing.Size(691, 283);
            this.KHdata.TabIndex = 2;
            this.KHdata.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.KHdata_CellClick);
            this.KHdata.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.KHdata_CellContentClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.KHexit);
            this.groupBox2.Controls.Add(this.KHdelete);
            this.groupBox2.Controls.Add(this.KHupdate);
            this.groupBox2.Controls.Add(this.KHadd);
            this.groupBox2.Controls.Add(this.KHload);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Blue;
            this.groupBox2.Location = new System.Drawing.Point(4, 161);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(167, 283);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Chức Năng";
            // 
            // KHexit
            // 
            this.KHexit.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KHexit.ForeColor = System.Drawing.Color.Blue;
            this.KHexit.Image = global::DOAN.Properties.Resources.Button_Close_icon;
            this.KHexit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.KHexit.Location = new System.Drawing.Point(0, 236);
            this.KHexit.Name = "KHexit";
            this.KHexit.Size = new System.Drawing.Size(167, 46);
            this.KHexit.TabIndex = 4;
            this.KHexit.Text = "&Thoát";
            this.KHexit.UseVisualStyleBackColor = true;
            this.KHexit.Click += new System.EventHandler(this.KHexit_Click);
            // 
            // KHdelete
            // 
            this.KHdelete.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KHdelete.ForeColor = System.Drawing.Color.Blue;
            this.KHdelete.Image = ((System.Drawing.Image)(resources.GetObject("KHdelete.Image")));
            this.KHdelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.KHdelete.Location = new System.Drawing.Point(0, 180);
            this.KHdelete.Name = "KHdelete";
            this.KHdelete.Size = new System.Drawing.Size(167, 46);
            this.KHdelete.TabIndex = 3;
            this.KHdelete.Text = "&Xóa";
            this.KHdelete.UseVisualStyleBackColor = true;
            this.KHdelete.Click += new System.EventHandler(this.nvdelete_Click);
            // 
            // KHupdate
            // 
            this.KHupdate.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KHupdate.ForeColor = System.Drawing.Color.Blue;
            this.KHupdate.Image = ((System.Drawing.Image)(resources.GetObject("KHupdate.Image")));
            this.KHupdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.KHupdate.Location = new System.Drawing.Point(0, 125);
            this.KHupdate.Name = "KHupdate";
            this.KHupdate.Size = new System.Drawing.Size(167, 46);
            this.KHupdate.TabIndex = 2;
            this.KHupdate.Text = "&Sửa";
            this.KHupdate.UseVisualStyleBackColor = true;
            this.KHupdate.Click += new System.EventHandler(this.KHupdate_Click);
            // 
            // KHadd
            // 
            this.KHadd.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KHadd.ForeColor = System.Drawing.Color.Blue;
            this.KHadd.Image = ((System.Drawing.Image)(resources.GetObject("KHadd.Image")));
            this.KHadd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.KHadd.Location = new System.Drawing.Point(-1, 70);
            this.KHadd.Name = "KHadd";
            this.KHadd.Size = new System.Drawing.Size(167, 46);
            this.KHadd.TabIndex = 1;
            this.KHadd.Text = "&Thêm";
            this.KHadd.UseVisualStyleBackColor = true;
            this.KHadd.Click += new System.EventHandler(this.KHadd_Click);
            // 
            // KHload
            // 
            this.KHload.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KHload.ForeColor = System.Drawing.Color.Blue;
            this.KHload.Image = ((System.Drawing.Image)(resources.GetObject("KHload.Image")));
            this.KHload.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.KHload.Location = new System.Drawing.Point(0, 16);
            this.KHload.Name = "KHload";
            this.KHload.Size = new System.Drawing.Size(167, 46);
            this.KHload.TabIndex = 0;
            this.KHload.Text = "&Làm Mới";
            this.KHload.UseVisualStyleBackColor = true;
            this.KHload.Click += new System.EventHandler(this.KHload_Click);
            // 
            // TTKH
            // 
            this.TTKH.Controls.Add(this.KHsdt);
            this.TTKH.Controls.Add(this.KHdate);
            this.TTKH.Controls.Add(this.KHDongia);
            this.TTKH.Controls.Add(this.label12);
            this.TTKH.Controls.Add(this.KHtheloai);
            this.TTKH.Controls.Add(this.label11);
            this.TTKH.Controls.Add(this.label10);
            this.TTKH.Controls.Add(this.KHsoluog);
            this.TTKH.Controls.Add(this.label7);
            this.TTKH.Controls.Add(this.KHhoten);
            this.TTKH.Controls.Add(this.tien);
            this.TTKH.Controls.Add(this.label9);
            this.TTKH.Controls.Add(this.KHtendia);
            this.TTKH.Controls.Add(this.label8);
            this.TTKH.Controls.Add(this.KHgt);
            this.TTKH.Controls.Add(this.label6);
            this.TTKH.Controls.Add(this.CC);
            this.TTKH.Controls.Add(this.label4);
            this.TTKH.Controls.Add(this.label3);
            this.TTKH.Controls.Add(this.label2);
            this.TTKH.Controls.Add(this.KHma);
            this.TTKH.Controls.Add(this.label1);
            this.TTKH.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TTKH.ForeColor = System.Drawing.Color.Blue;
            this.TTKH.Location = new System.Drawing.Point(4, 25);
            this.TTKH.Name = "TTKH";
            this.TTKH.Size = new System.Drawing.Size(871, 130);
            this.TTKH.TabIndex = 0;
            this.TTKH.TabStop = false;
            this.TTKH.Text = "Thông tin khách hàng";
            this.TTKH.Enter += new System.EventHandler(this.TTNV_Enter);
            // 
            // KHsdt
            // 
            this.KHsdt.Location = new System.Drawing.Point(308, 20);
            this.KHsdt.Mask = "0000-000-000";
            this.KHsdt.Name = "KHsdt";
            this.KHsdt.Size = new System.Drawing.Size(100, 21);
            this.KHsdt.TabIndex = 4;
            this.KHsdt.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.KHsdt_MaskInputRejected);
            // 
            // KHdate
            // 
            this.KHdate.Enabled = false;
            this.KHdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.KHdate.Location = new System.Drawing.Point(308, 60);
            this.KHdate.MaxDate = new System.DateTime(2909, 12, 31, 0, 0, 0, 0);
            this.KHdate.Name = "KHdate";
            this.KHdate.Size = new System.Drawing.Size(100, 21);
            this.KHdate.TabIndex = 5;
            this.KHdate.Value = new System.DateTime(2022, 10, 23, 0, 0, 0, 0);
            // 
            // KHDongia
            // 
            this.KHDongia.Enabled = false;
            this.KHDongia.FormattingEnabled = true;
            this.KHDongia.Location = new System.Drawing.Point(517, 97);
            this.KHDongia.Name = "KHDongia";
            this.KHDongia.Size = new System.Drawing.Size(100, 23);
            this.KHDongia.TabIndex = 9;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Blue;
            this.label12.Location = new System.Drawing.Point(463, 100);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 15);
            this.label12.TabIndex = 23;
            this.label12.Text = "Đơn Gía";
            // 
            // KHtheloai
            // 
            this.KHtheloai.FormattingEnabled = true;
            this.KHtheloai.Location = new System.Drawing.Point(308, 94);
            this.KHtheloai.Name = "KHtheloai";
            this.KHtheloai.Size = new System.Drawing.Size(100, 23);
            this.KHtheloai.TabIndex = 6;
            this.KHtheloai.SelectedIndexChanged += new System.EventHandler(this.KHtheloai_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Blue;
            this.label11.Location = new System.Drawing.Point(243, 97);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 15);
            this.label11.TabIndex = 21;
            this.label11.Text = "Thể Loại";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(458, 60);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 15);
            this.label10.TabIndex = 20;
            this.label10.Text = "Số Lượng";
            // 
            // KHsoluog
            // 
            this.KHsoluog.Location = new System.Drawing.Point(517, 58);
            this.KHsoluog.Name = "KHsoluog";
            this.KHsoluog.Size = new System.Drawing.Size(100, 21);
            this.KHsoluog.TabIndex = 8;
            this.KHsoluog.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KHsoluog_KeyPress);
            this.KHsoluog.KeyUp += new System.Windows.Forms.KeyEventHandler(this.KHsoluog_KeyUp);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(35, 56);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 15);
            this.label7.TabIndex = 18;
            this.label7.Text = "Họ Tên";
            // 
            // KHhoten
            // 
            this.KHhoten.Location = new System.Drawing.Point(84, 54);
            this.KHhoten.Name = "KHhoten";
            this.KHhoten.Size = new System.Drawing.Size(100, 21);
            this.KHhoten.TabIndex = 2;
            // 
            // tien
            // 
            this.tien.Enabled = false;
            this.tien.FormattingEnabled = true;
            this.tien.Location = new System.Drawing.Point(685, 89);
            this.tien.Name = "tien";
            this.tien.Size = new System.Drawing.Size(117, 23);
            this.tien.TabIndex = 16;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(711, 73);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 15);
            this.label9.TabIndex = 15;
            this.label9.Text = "Thành Tiền";
            // 
            // KHtendia
            // 
            this.KHtendia.FormattingEnabled = true;
            this.KHtendia.Location = new System.Drawing.Point(517, 18);
            this.KHtendia.Name = "KHtendia";
            this.KHtendia.Size = new System.Drawing.Size(100, 23);
            this.KHtendia.TabIndex = 7;
            this.KHtendia.SelectedIndexChanged += new System.EventHandler(this.KHtendia_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(465, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 15);
            this.label8.TabIndex = 13;
            this.label8.Text = "Tên Đĩa";
            // 
            // KHgt
            // 
            this.KHgt.FormattingEnabled = true;
            this.KHgt.Location = new System.Drawing.Point(84, 92);
            this.KHgt.Name = "KHgt";
            this.KHgt.Size = new System.Drawing.Size(102, 23);
            this.KHgt.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(243, 61);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 15);
            this.label6.TabIndex = 9;
            this.label6.Text = "Thời Gian";
            // 
            // CC
            // 
            this.CC.Enabled = false;
            this.CC.FormattingEnabled = true;
            this.CC.Location = new System.Drawing.Point(685, 43);
            this.CC.Name = "CC";
            this.CC.Size = new System.Drawing.Size(117, 23);
            this.CC.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(704, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Số Hàng Còn";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(27, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Giới Tính";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(243, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Số ĐT";
            // 
            // KHma
            // 
            this.KHma.Location = new System.Drawing.Point(84, 19);
            this.KHma.Name = "KHma";
            this.KHma.Size = new System.Drawing.Size(100, 21);
            this.KHma.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(32, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã KH";
            // 
            // KhachHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(890, 450);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "KhachHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "KhachHang";
            this.Load += new System.EventHandler(this.KhachHang_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.KHdata)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.TTKH.ResumeLayout(false);
            this.TTKH.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView KHdata;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button KHexit;
        private System.Windows.Forms.Button KHdelete;
        private System.Windows.Forms.Button KHupdate;
        private System.Windows.Forms.Button KHadd;
        private System.Windows.Forms.Button KHload;
        private System.Windows.Forms.GroupBox TTKH;
        private System.Windows.Forms.ComboBox tien;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox KHtendia;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox KHgt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox CC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox KHma;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox KHtheloai;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox KHsoluog;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox KHhoten;
        private System.Windows.Forms.DateTimePicker KHdate;
        private System.Windows.Forms.ComboBox KHDongia;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.MaskedTextBox KHsdt;
    }
}