﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DOAN
{
    public partial class NhanVien : Form
    {
        public NhanVien()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adt;
        SqlDataReader dr;
        DataTable data;
        string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\THANHLONG;Initial Catalog=DOAN;Integrated Security=True";


        public void mokn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

        }
        public void dongkn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }
        void thucthisql(string sql)
        {
            mokn();
            cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            dongkn();
        }
        void gioitinh_Load()
        {

            mokn();
            cmd = new SqlCommand("Select * from GioiTinh", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                NVgioitinh.Items.Add(dr[0].ToString());
            }
            dongkn();
        }

        int NVkiemtramatrung(string NVma)
        {
            int i;
            mokn();
            string sql = "Select count(*) from NhanVien where Ma='" + NVma.Trim() + "'";
            cmd = new SqlCommand(sql, con);
            i = (int)(cmd.ExecuteScalar());
            dongkn();
            return i;
        }
        void NVloaddgv_phikn()
        {
            mokn();
            adt = new SqlDataAdapter("Select * from NhanVien", con);
            data = new DataTable();
            adt.Fill(data);
            NVdata.DataSource = data;
            
            NVdata.Columns[0].HeaderText = "Mã NV";
            NVdata.Columns[1].HeaderText = "Tên Nhân Viên";
            NVdata.Columns[2].HeaderText = "SĐT NV";
            NVdata.Columns[3].HeaderText = "giới tính";
            NVdata.Columns[4].HeaderText = "Ngày Nghỉ";
            NVdata.Columns[5].HeaderText = "Chức Vụ";
            NVdata.Columns[6].HeaderText = "Ca làm";
            NVdata.Columns[7].HeaderText = "Lương/h";
            NVdata.Columns[8].HeaderText = "Lương";
        }

        private void NVlammoi()
        {
            foreach (Control ctrl in TTNV.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }
            NVSoDT.Text = "";
            TTNV.Enabled = true;
            NVma.Enabled = true;
        }
        //private void tinhluong()
        //{

        //    int g;
        //    if (ca.Text == "FullTime")
        //    { g = 14; }
        //    else g = 7;
        //    double lu = int.Parse(luongh.Text) * g;

        //    luong.Text = lu.ToString();

        //}
        private void tinh()
        {
            if(chucvu.Text=="Quản Lý")
            {
                if(ca.Text=="FullTime")
                {
                    double lu = (int.Parse(luongh.Text) * 14 + 40000)*30-(int.Parse(nghi.Text)*(int.Parse(luongh.Text)*14));
                    luong.Text = lu.ToString();
                    
                }
                else
                {
                    double lu = (int.Parse(luongh.Text) * 7 + 20000) * 30 - (int.Parse(nghi.Text) * (int.Parse(luongh.Text)*7));
                    luong.Text = lu.ToString();
                }
            }    
            else
            {
                if (ca.Text == "FullTime")
                {
                    double lu = (int.Parse(luongh.Text) * 14 +50000) * 30 - ((int.Parse(nghi.Text) * int.Parse(luongh.Text)*14));
                    luong.Text = lu.ToString();
                }
                else
                {
                    double lu = (int.Parse(luongh.Text) * 7 + 25000) * 30 - (int.Parse(nghi.Text) * (int.Parse(luongh.Text)*7));
                    luong.Text = lu.ToString();
                }
            }
            
        }    
        private void TTCC_Enter(object sender, EventArgs e)
        {

        }

        private void CCma_TextChanged(object sender, EventArgs e)
        {

        }

        private void NVdata_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) return;
            NVma.Text = NVdata[0, i].Value.ToString();
            NVHoTen.Text = NVdata[1, i].Value.ToString();
            NVSoDT.Text = NVdata[2, i].Value.ToString();
            NVgioitinh.Text = NVdata[3, i].Value.ToString();
            nghi.Text = NVdata[4, i].Value.ToString();

            chucvu.Text = NVdata[5, i].Value.ToString();
            ca.Text = NVdata[6, i].Value.ToString();
            luongh.Text = NVdata[7, i].Value.ToString();
            luong.Text = NVdata[8, i].Value.ToString();



            NVma.Enabled = false;
        }

        private void chucvu_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (chucvu.Text == "Quản Lý")
            {
                luongh.Text = "40000";
            }
            else
                luongh.Text = "25000";
            
        }

 

        private void luongh_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void ca_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            tinh();
        }

        private void nvload_Click(object sender, EventArgs e)
        {
            foreach (Control ctrl in TTNV.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }
            NVSoDT.Text = "";
            TTNV.Enabled = true;
            NVma.Enabled = true;
        }

        private void nvadd_Click(object sender, EventArgs e)
        {
            int g;
            string maaNV = "NV" + NVma.Text;
            string tennNV = NVHoTen.Text;
            string SĐT = NVSoDT.Text;
            if (SĐT.Length < 10)
            {
                MessageBox.Show("Số điện thoại của bạn chưa đúng! hãy nhập lại ", "thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            string GT = NVgioitinh.Text;
            string nn=nghi.Text;
            string cv = chucvu.Text;
            string c = ca.Text;
            string lh = luongh.Text;
            if (chucvu.Text == "Quản Lý")
            {
                if (ca.Text == "FullTime")
                {
                    double lu = (int.Parse(luongh.Text) * 14 + 40000) * 30 -( (int.Parse(nghi.Text) * int.Parse(luongh.Text)*14));
                    luong.Text = lu.ToString();

                }
                else
                {
                    double lu = (int.Parse(luongh.Text) * 7 + 20000) * 30 - ((int.Parse(nghi.Text) * int.Parse(luongh.Text)*7));
                    luong.Text = lu.ToString();
                }
            }
            else
            {
                if (ca.Text == "FullTime")
                {
                    double lu = (int.Parse(luongh.Text) * 14 + 50000) * 30 - (int.Parse(nghi.Text) *( int.Parse(luongh.Text)*14));
                    luong.Text = lu.ToString();
                }
                else
                {
                    double lu = (int.Parse(luongh.Text) * 7 + 25000) * 30 - (int.Parse(nghi.Text) * (int.Parse(luongh.Text)*7));
                    luong.Text = lu.ToString();
                }
            }
               


                string sql = " Insert into NhanVien values ('" + maaNV + "', N'" + tennNV + "', '" + SĐT + "', N'" + GT + "','"+nn+"',N'" + cv + "',N'" + c + "','" + lh + "','" + luong.Text + "')";
            if (NVkiemtramatrung(NVma.Text) == 1)
            {
                MessageBox.Show("Mã NV đã tồn tại, bạn hãy nhập lại mã khác!!!", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            }
            else
            {
                thucthisql(sql);
                NVloaddgv_phikn();
            }
            NVlammoi();
        }
        public void nn()
        {
            label5.Text = "Employee manager";TTNV.Text = "Staff information";label1.Text = "ID";label2.Text = "Full Name";label3.Text = "Phone NumBer";
            label4.Text = "Sex";label10.Text = "Day off";label6.Text = "Position";label7.Text = "Shift work";label8.Text = "Salary/hour";label9.Text = "Wage";groupBox2.Text = "Position";groupBox3.Text = "List of employee";nvload.Text = "Refersh";
            nvadd.Text = "Insert";nvupdate.Text = "Update";nvdelete.Text = "Delete";
            nvexit.Text = "Exit";
        }

        private void nvupdate_Click(object sender, EventArgs e)
        {
            string Ma = NVma.Text;
            string ten = NVHoTen.Text;
            string SDT=NVSoDT.Text;
            if (SDT.Length < 10)
            {
                MessageBox.Show("Số điện thoại của bạn chưa đúng! hãy nhập lại ", "thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            string gt = NVgioitinh.Text;
            string nn=nghi.Text;
            string cv = chucvu.Text;
            string c = ca.Text;
            string lh = luongh.Text;

           
            if (chucvu.Text == "Quản Lý")
            {
                if (ca.Text == "FullTime")
                {
                    double lu = (int.Parse(luongh.Text) * 14 + 40000) * 30 - (int.Parse(nghi.Text) * int.Parse(luongh.Text));
                    luong.Text = lu.ToString();

                }
                else
                {
                    double lu = (int.Parse(luongh.Text) * 7 + 20000) * 30 - (int.Parse(nghi.Text) * int.Parse(luongh.Text));
                    luong.Text = lu.ToString();
                }
            }
            else
            {
                if (ca.Text == "FullTime")
                {
                    double lu = (int.Parse(luongh.Text) * 14 + 50000) * 30 - (int.Parse(nghi.Text) * int.Parse(luongh.Text));
                    luong.Text = lu.ToString();
                }
                else
                {
                    double lu = (int.Parse(luongh.Text) * 7 + 25000) * 30 - (int.Parse(nghi.Text) * int.Parse(luongh.Text));
                    luong.Text = lu.ToString();
                }
            }
            string sql = "Update NhanVien set Ten= N'" + ten + "',SDT='" + SDT + "',GioiTinh=N'" + gt + "',NgayNghi='"+nn+"',ChucVu=N'" +cv+ "',CaLam=N'" +c+ "',Luongh='" + lh + "',Luong='" + luong.Text + "' where Ma='" + Ma + "'";
            thucthisql(sql);
            NVloaddgv_phikn();
            NVlammoi();
        }

        private void nvdelete_Click(object sender, EventArgs e)
        {
            string manv = NVma.Text;
            string sql = "Delete from NhanVien where Ma='" + manv + "' ";


            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa NHÂN VIÊN này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                thucthisql(sql);
                NVloaddgv_phikn();
                NVlammoi();
            }
        }

        private void nvexit_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }

        private void NhanVien_Load(object sender, EventArgs e)
        {
            NVloaddgv_phikn();
            gioitinh_Load();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void nghi_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
