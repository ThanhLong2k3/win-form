﻿namespace DOAN
{
    partial class DaiLy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DaiLy));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.DLdata = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.DLexit = new System.Windows.Forms.Button();
            this.DLdelete = new System.Windows.Forms.Button();
            this.DLupdate = new System.Windows.Forms.Button();
            this.DLadd = new System.Windows.Forms.Button();
            this.DLload = new System.Windows.Forms.Button();
            this.TTDL = new System.Windows.Forms.GroupBox();
            this.DLdt = new System.Windows.Forms.MaskedTextBox();
            this.DLdc = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.DLten = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.DLma = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DLdata)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.TTDL.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.TTDL);
            this.panel1.ForeColor = System.Drawing.Color.Blue;
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(964, 447);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.label5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.ForeColor = System.Drawing.Color.Blue;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(964, 47);
            this.panel2.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(372, 9);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(204, 31);
            this.label5.TabIndex = 8;
            this.label5.Text = "Quản Lý Đại Lý";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.White;
            this.groupBox3.Controls.Add(this.DLdata);
            this.groupBox3.ForeColor = System.Drawing.Color.Blue;
            this.groupBox3.Location = new System.Drawing.Point(179, 142);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Size = new System.Drawing.Size(771, 302);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Danh Sách Đại Lý";
            // 
            // DLdata
            // 
            this.DLdata.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DLdata.BackgroundColor = System.Drawing.Color.White;
            this.DLdata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DLdata.Location = new System.Drawing.Point(-2, 20);
            this.DLdata.Name = "DLdata";
            this.DLdata.Size = new System.Drawing.Size(766, 276);
            this.DLdata.TabIndex = 0;
            this.DLdata.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DLdata_CellClick);
            this.DLdata.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DLdata_CellContentClick);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.DLexit);
            this.groupBox2.Controls.Add(this.DLdelete);
            this.groupBox2.Controls.Add(this.DLupdate);
            this.groupBox2.Controls.Add(this.DLadd);
            this.groupBox2.Controls.Add(this.DLload);
            this.groupBox2.ForeColor = System.Drawing.Color.Blue;
            this.groupBox2.Location = new System.Drawing.Point(5, 142);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Size = new System.Drawing.Size(171, 302);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Chức Năng";
            // 
            // DLexit
            // 
            this.DLexit.BackColor = System.Drawing.Color.White;
            this.DLexit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.DLexit.ForeColor = System.Drawing.Color.Blue;
            this.DLexit.Image = ((System.Drawing.Image)(resources.GetObject("DLexit.Image")));
            this.DLexit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DLexit.Location = new System.Drawing.Point(-1, 247);
            this.DLexit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DLexit.Name = "DLexit";
            this.DLexit.Size = new System.Drawing.Size(167, 46);
            this.DLexit.TabIndex = 4;
            this.DLexit.Text = "&Thoát";
            this.DLexit.UseVisualStyleBackColor = false;
            this.DLexit.Click += new System.EventHandler(this.DLexit_Click);
            // 
            // DLdelete
            // 
            this.DLdelete.BackColor = System.Drawing.Color.White;
            this.DLdelete.ForeColor = System.Drawing.Color.Blue;
            this.DLdelete.Image = ((System.Drawing.Image)(resources.GetObject("DLdelete.Image")));
            this.DLdelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DLdelete.Location = new System.Drawing.Point(0, 191);
            this.DLdelete.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DLdelete.Name = "DLdelete";
            this.DLdelete.Size = new System.Drawing.Size(167, 46);
            this.DLdelete.TabIndex = 3;
            this.DLdelete.Text = "&Xóa";
            this.DLdelete.UseVisualStyleBackColor = false;
            this.DLdelete.Click += new System.EventHandler(this.DLdelete_Click);
            // 
            // DLupdate
            // 
            this.DLupdate.BackColor = System.Drawing.Color.White;
            this.DLupdate.ForeColor = System.Drawing.Color.Blue;
            this.DLupdate.Image = ((System.Drawing.Image)(resources.GetObject("DLupdate.Image")));
            this.DLupdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DLupdate.Location = new System.Drawing.Point(0, 135);
            this.DLupdate.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DLupdate.Name = "DLupdate";
            this.DLupdate.Size = new System.Drawing.Size(167, 46);
            this.DLupdate.TabIndex = 2;
            this.DLupdate.Text = "&Sửa";
            this.DLupdate.UseVisualStyleBackColor = false;
            this.DLupdate.Click += new System.EventHandler(this.DLupdate_Click);
            // 
            // DLadd
            // 
            this.DLadd.BackColor = System.Drawing.Color.White;
            this.DLadd.ForeColor = System.Drawing.Color.Blue;
            this.DLadd.Image = ((System.Drawing.Image)(resources.GetObject("DLadd.Image")));
            this.DLadd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DLadd.Location = new System.Drawing.Point(0, 79);
            this.DLadd.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DLadd.Name = "DLadd";
            this.DLadd.Size = new System.Drawing.Size(167, 46);
            this.DLadd.TabIndex = 1;
            this.DLadd.Text = "&Thêm";
            this.DLadd.UseVisualStyleBackColor = false;
            this.DLadd.Click += new System.EventHandler(this.DLadd_Click);
            // 
            // DLload
            // 
            this.DLload.BackColor = System.Drawing.Color.White;
            this.DLload.ForeColor = System.Drawing.Color.Blue;
            this.DLload.Image = ((System.Drawing.Image)(resources.GetObject("DLload.Image")));
            this.DLload.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DLload.Location = new System.Drawing.Point(0, 20);
            this.DLload.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DLload.Name = "DLload";
            this.DLload.Size = new System.Drawing.Size(167, 46);
            this.DLload.TabIndex = 0;
            this.DLload.Text = "&Làm Mới";
            this.DLload.UseVisualStyleBackColor = false;
            this.DLload.Click += new System.EventHandler(this.DLload_Click);
            // 
            // TTDL
            // 
            this.TTDL.BackColor = System.Drawing.Color.White;
            this.TTDL.Controls.Add(this.DLdt);
            this.TTDL.Controls.Add(this.DLdc);
            this.TTDL.Controls.Add(this.label4);
            this.TTDL.Controls.Add(this.label3);
            this.TTDL.Controls.Add(this.DLten);
            this.TTDL.Controls.Add(this.label2);
            this.TTDL.Controls.Add(this.DLma);
            this.TTDL.Controls.Add(this.label1);
            this.TTDL.ForeColor = System.Drawing.Color.Blue;
            this.TTDL.Location = new System.Drawing.Point(5, 53);
            this.TTDL.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TTDL.Name = "TTDL";
            this.TTDL.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TTDL.Size = new System.Drawing.Size(945, 82);
            this.TTDL.TabIndex = 0;
            this.TTDL.TabStop = false;
            this.TTDL.Text = "Đại Lý";
            // 
            // DLdt
            // 
            this.DLdt.Location = new System.Drawing.Point(547, 31);
            this.DLdt.Mask = "0000-000-000";
            this.DLdt.Name = "DLdt";
            this.DLdt.Size = new System.Drawing.Size(127, 20);
            this.DLdt.TabIndex = 8;
            // 
            // DLdc
            // 
            this.DLdc.Location = new System.Drawing.Point(769, 31);
            this.DLdc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DLdc.Name = "DLdc";
            this.DLdc.Size = new System.Drawing.Size(116, 20);
            this.DLdc.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(708, 34);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Địa Chỉ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(503, 31);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Số ĐT";
            // 
            // DLten
            // 
            this.DLten.Location = new System.Drawing.Point(335, 31);
            this.DLten.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DLten.Name = "DLten";
            this.DLten.Size = new System.Drawing.Size(116, 20);
            this.DLten.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(259, 34);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Họ Và Tên";
            // 
            // DLma
            // 
            this.DLma.Location = new System.Drawing.Point(99, 31);
            this.DLma.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DLma.Name = "DLma";
            this.DLma.Size = new System.Drawing.Size(116, 20);
            this.DLma.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(38, 31);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã DL";
            // 
            // DaiLy
            // 
            this.AcceptButton = this.DLadd;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.DLexit;
            this.ClientSize = new System.Drawing.Size(964, 450);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Blue;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "DaiLy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DaiLy";
            this.Load += new System.EventHandler(this.DaiLy_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DLdata)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.TTDL.ResumeLayout(false);
            this.TTDL.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox TTDL;
        private System.Windows.Forms.TextBox DLdc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox DLten;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox DLma;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button DLexit;
        private System.Windows.Forms.Button DLdelete;
        private System.Windows.Forms.Button DLupdate;
        private System.Windows.Forms.Button DLadd;
        private System.Windows.Forms.Button DLload;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.MaskedTextBox DLdt;
        private System.Windows.Forms.DataGridView DLdata;
    }
}