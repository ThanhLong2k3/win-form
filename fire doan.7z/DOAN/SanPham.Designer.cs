﻿namespace DOAN
{
    partial class SanPham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.SPdata = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.SPexit = new System.Windows.Forms.Button();
            this.SPdelete = new System.Windows.Forms.Button();
            this.SPupdate = new System.Windows.Forms.Button();
            this.SPadd = new System.Windows.Forms.Button();
            this.SPload = new System.Windows.Forms.Button();
            this.TTSP = new System.Windows.Forms.GroupBox();
            this.dongia = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.soluong = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.theloai = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.mota = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tendia = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.masp = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SPdata)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.TTSP.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.TTSP);
            this.panel1.Location = new System.Drawing.Point(4, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(927, 516);
            this.panel1.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(316, 4);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(243, 31);
            this.label5.TabIndex = 8;
            this.label5.Text = "Quản Lý Sản Phẩm";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.SPdata);
            this.groupBox3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.Blue;
            this.groupBox3.Location = new System.Drawing.Point(180, 164);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Size = new System.Drawing.Size(736, 348);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Danh Sách Sản Phẩm";
            // 
            // SPdata
            // 
            this.SPdata.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.SPdata.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.SPdata.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SPdata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SPdata.Location = new System.Drawing.Point(7, 22);
            this.SPdata.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SPdata.Name = "SPdata";
            this.SPdata.Size = new System.Drawing.Size(729, 327);
            this.SPdata.TabIndex = 2;
            this.SPdata.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SPdata_CellClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.SPexit);
            this.groupBox2.Controls.Add(this.SPdelete);
            this.groupBox2.Controls.Add(this.SPupdate);
            this.groupBox2.Controls.Add(this.SPadd);
            this.groupBox2.Controls.Add(this.SPload);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Blue;
            this.groupBox2.Location = new System.Drawing.Point(5, 164);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Size = new System.Drawing.Size(171, 348);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Chức Năng";
            // 
            // SPexit
            // 
            this.SPexit.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SPexit.ForeColor = System.Drawing.Color.Blue;
            this.SPexit.Image = global::DOAN.Properties.Resources.Button_Close_icon;
            this.SPexit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SPexit.Location = new System.Drawing.Point(0, 255);
            this.SPexit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SPexit.Name = "SPexit";
            this.SPexit.Size = new System.Drawing.Size(167, 46);
            this.SPexit.TabIndex = 4;
            this.SPexit.Text = "&Thoát";
            this.SPexit.UseVisualStyleBackColor = true;
            this.SPexit.Click += new System.EventHandler(this.SPexit_Click);
            // 
            // SPdelete
            // 
            this.SPdelete.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SPdelete.ForeColor = System.Drawing.Color.Blue;
            this.SPdelete.Image = global::DOAN.Properties.Resources.trash_icon;
            this.SPdelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SPdelete.Location = new System.Drawing.Point(0, 197);
            this.SPdelete.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SPdelete.Name = "SPdelete";
            this.SPdelete.Size = new System.Drawing.Size(167, 46);
            this.SPdelete.TabIndex = 3;
            this.SPdelete.Text = "&Xóa";
            this.SPdelete.UseVisualStyleBackColor = true;
            this.SPdelete.Click += new System.EventHandler(this.SPdelete_Click);
            // 
            // SPupdate
            // 
            this.SPupdate.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SPupdate.ForeColor = System.Drawing.Color.Blue;
            this.SPupdate.Image = global::DOAN.Properties.Resources.fix_it_icon;
            this.SPupdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SPupdate.Location = new System.Drawing.Point(0, 138);
            this.SPupdate.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SPupdate.Name = "SPupdate";
            this.SPupdate.Size = new System.Drawing.Size(167, 46);
            this.SPupdate.TabIndex = 2;
            this.SPupdate.Text = "&Sửa";
            this.SPupdate.UseVisualStyleBackColor = true;
            this.SPupdate.Click += new System.EventHandler(this.SPupdate_Click);
            // 
            // SPadd
            // 
            this.SPadd.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SPadd.ForeColor = System.Drawing.Color.Blue;
            this.SPadd.Image = global::DOAN.Properties.Resources.add_icon;
            this.SPadd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SPadd.Location = new System.Drawing.Point(-1, 81);
            this.SPadd.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SPadd.Name = "SPadd";
            this.SPadd.Size = new System.Drawing.Size(167, 46);
            this.SPadd.TabIndex = 1;
            this.SPadd.Text = "&Thêm";
            this.SPadd.UseVisualStyleBackColor = true;
            this.SPadd.Click += new System.EventHandler(this.SPadd_Click);
            // 
            // SPload
            // 
            this.SPload.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SPload.ForeColor = System.Drawing.Color.Blue;
            this.SPload.Image = global::DOAN.Properties.Resources.sync_icon;
            this.SPload.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SPload.Location = new System.Drawing.Point(0, 23);
            this.SPload.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SPload.Name = "SPload";
            this.SPload.Size = new System.Drawing.Size(167, 46);
            this.SPload.TabIndex = 0;
            this.SPload.Text = "&Làm Mới";
            this.SPload.UseVisualStyleBackColor = true;
            this.SPload.Click += new System.EventHandler(this.SPload_Click);
            // 
            // TTSP
            // 
            this.TTSP.Controls.Add(this.dongia);
            this.TTSP.Controls.Add(this.label6);
            this.TTSP.Controls.Add(this.soluong);
            this.TTSP.Controls.Add(this.label7);
            this.TTSP.Controls.Add(this.theloai);
            this.TTSP.Controls.Add(this.label4);
            this.TTSP.Controls.Add(this.mota);
            this.TTSP.Controls.Add(this.label3);
            this.TTSP.Controls.Add(this.tendia);
            this.TTSP.Controls.Add(this.label2);
            this.TTSP.Controls.Add(this.masp);
            this.TTSP.Controls.Add(this.label1);
            this.TTSP.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TTSP.ForeColor = System.Drawing.Color.Blue;
            this.TTSP.Location = new System.Drawing.Point(5, 39);
            this.TTSP.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TTSP.Name = "TTSP";
            this.TTSP.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TTSP.Size = new System.Drawing.Size(913, 118);
            this.TTSP.TabIndex = 0;
            this.TTSP.TabStop = false;
            this.TTSP.Text = "Thông tin sản Phẩm";
            this.TTSP.Enter += new System.EventHandler(this.TTSP_Enter);
            // 
            // dongia
            // 
            this.dongia.Location = new System.Drawing.Point(692, 84);
            this.dongia.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dongia.Name = "dongia";
            this.dongia.Size = new System.Drawing.Size(180, 22);
            this.dongia.TabIndex = 12;
            this.dongia.TextChanged += new System.EventHandler(this.dongia_TextChanged);
            this.dongia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(616, 88);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 15);
            this.label6.TabIndex = 11;
            this.label6.Text = "Đơn Gía";
            // 
            // soluong
            // 
            this.soluong.Location = new System.Drawing.Point(366, 84);
            this.soluong.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.soluong.Name = "soluong";
            this.soluong.Size = new System.Drawing.Size(180, 22);
            this.soluong.TabIndex = 10;
            this.soluong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox2_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(301, 87);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 15);
            this.label7.TabIndex = 9;
            this.label7.Text = "Số Lượng";
            // 
            // theloai
            // 
            this.theloai.FormattingEnabled = true;
            this.theloai.Location = new System.Drawing.Point(691, 37);
            this.theloai.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.theloai.Name = "theloai";
            this.theloai.Size = new System.Drawing.Size(180, 23);
            this.theloai.TabIndex = 8;
            this.theloai.SelectedIndexChanged += new System.EventHandler(this.NVgioitinh_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(616, 41);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Thể Loại";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // mota
            // 
            this.mota.Location = new System.Drawing.Point(99, 84);
            this.mota.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.mota.Name = "mota";
            this.mota.Size = new System.Drawing.Size(153, 22);
            this.mota.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(38, 88);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Mỗ Tả";
            // 
            // tendia
            // 
            this.tendia.Location = new System.Drawing.Point(366, 36);
            this.tendia.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tendia.Name = "tendia";
            this.tendia.Size = new System.Drawing.Size(180, 22);
            this.tendia.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(307, 39);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tên Đĩa";
            // 
            // masp
            // 
            this.masp.Location = new System.Drawing.Point(99, 36);
            this.masp.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.masp.Name = "masp";
            this.masp.Size = new System.Drawing.Size(153, 22);
            this.masp.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(38, 36);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã SP";
            // 
            // SanPham
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 519);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Blue;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "SanPham";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SanPham";
            this.Load += new System.EventHandler(this.SanPham_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SPdata)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.TTSP.ResumeLayout(false);
            this.TTSP.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView SPdata;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button SPexit;
        private System.Windows.Forms.Button SPdelete;
        private System.Windows.Forms.Button SPupdate;
        private System.Windows.Forms.Button SPadd;
        private System.Windows.Forms.Button SPload;
        private System.Windows.Forms.GroupBox TTSP;
        private System.Windows.Forms.ComboBox theloai;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox mota;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tendia;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox masp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox dongia;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox soluong;
        private System.Windows.Forms.Label label7;
    }
}