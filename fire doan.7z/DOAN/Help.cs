﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DOAN
{
    public partial class Help : Form
    {
        private string tk;
      
        public Help(string tk)
        {
            InitializeComponent();
            this.tk = tk;
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adt;
        SqlDataReader dr;
        DataTable dt;
        string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\THANHLONG;Initial Catalog=DOAN;Integrated Security=True";
        public void lammoi()
        {
            foreach (Control ctrl in TTL.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }
            TTL.Enabled = true;
        }

        public void mokn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }
        void LoaiLoi_Load()//kiến trúc kết nối: connect, command, datareader
        {

            mokn();
            cmd = new SqlCommand("Select * from LoaiLoi", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                loai.Items.Add(dr[0].ToString());
            }
            dongkn();
        }
        public void dongkn()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
        void loadpkn()
        {
            mokn();
            adt = new SqlDataAdapter("select * from Help", con);
            dt = new DataTable();
            adt.Fill(dt);
            Ldata.DataSource = dt;
            Ldata.Columns[0].HeaderText = "Loại Lỗi";
            Ldata.Columns[1].HeaderText = "Tên Lỗi";
            Ldata.Columns[2].HeaderText = "Giair Quyết";

        }

        private void Ldata_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
             if (i == -1) return;
            loai.Text = Ldata[2, i].Value.ToString();
            vande.Text = Ldata[0, i].Value.ToString();
            giaiquyet.Text = Ldata[1, i].Value.ToString();
        }
        void thucthisql(string sql)
        {
            mokn();
            cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            dongkn();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string l = loai.Text;
            string loi = vande.Text;
            string gq = giaiquyet.Text;
            if (loi == "")
            {
                MessageBox.Show("bạn chưa nhập tên Lỗi!", "thông báo", MessageBoxButtons.OK);
            }
            else
            {
                string sql = "Insert into Help values(N'" + loi+"',N'" + gq+ "',N'" + l + "')";
                thucthisql(sql);
                loadpkn();
                lammoi();
            }

        }

        private void traloi_Click(object sender, EventArgs e)
        {
            string l = loai.Text;
            string loi = vande.Text;
            string gq = giaiquyet.Text;
            string sql = "Update Help set TenLoi = N'"+loi+"', GiaiQuyet = N'" + gq + "' where LoaiLoi=N'"+l+"' ";
            thucthisql(sql);
            loadpkn();
            lammoi();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string loi = vande.Text;
            if (loi == "")
            {
                MessageBox.Show("bạn chưa nhập tên Lỗi!", "thông báo", MessageBoxButtons.OK);
            }
            else
            {
                string sql = $"SELECT * FROM Help where TenLoi like N'%"+loi+"%'";
                adt = new SqlDataAdapter(sql, con);
                dt = new DataTable();
                adt.Fill(dt);
                Ldata.DataSource = dt;
                Ldata.Refresh();
                dongkn();

            }
        }

        private void loai_SelectedIndexChanged(object sender, EventArgs e)
        {
            string a = loai.SelectedItem.ToString();
            string sql = $"select *from Help where LoaiLoi=  N'" + a + "'";
            adt = new SqlDataAdapter(sql, con);
            dt = new DataTable();
            adt.Fill(dt);
            Ldata.DataSource = dt;
           
        }

        private void Help_Load(object sender, EventArgs e)
        {
            LoaiLoi_Load();
            loadpkn();
            if (tk != "admin")
            {
                traloi.Enabled = false;
                traloi.Visible = false;
                button4.Visible = false;
            }
        }

        private void giaiquyet_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            lammoi();
        }

        private void Ldata_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void TTL_Enter(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string l = vande.Text;
            string sql = "Delete from Help where TenLoi='" + l + "' ";


            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa Lỗi  này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                thucthisql(sql);
                loadpkn();
                lammoi();
            }
        }
    }
}
